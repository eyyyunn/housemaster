<?php
session_start();
include __DIR__ . "/../config.php";

// ✅ Require admin login
if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

$message = "";

// ✅ Handle Add Room
if (isset($_POST['add_room'])) {
    $room_label = $_POST['room_label'];
    $capacity    = $_POST['capacity'];
    $rental_rate = $_POST['rental_rate'];

    $stmt = $conn->prepare("INSERT INTO rooms (room_label, capacity, rental_rate) VALUES (?, ?, ?)");
    $stmt->bind_param("sid", $room_label, $capacity, $rental_rate);
    if ($stmt->execute()) {
        $message = "Room added successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}

// ✅ Handle Tenant Assignment
if (isset($_POST['assign_room'])) {
    $tenant_id = $_POST['tenant_id'];
    $room_id   = $_POST['room_id'];

    // Check if tenant already has a room
    $check = $conn->prepare("SELECT * FROM tenant_rooms WHERE tenant_id=?");
    $check->bind_param("i", $tenant_id);
    $check->execute();
    $exists = $check->get_result();

    if ($exists->num_rows > 0) {
        $message = "This tenant already has a room assigned.";
    } else {
        // Check room capacity
        $capacity_check = $conn->prepare("
            SELECT capacity, 
                   (SELECT COUNT(*) FROM tenant_rooms WHERE room_id=?) AS current_count
            FROM rooms WHERE id=?");
        $capacity_check->bind_param("ii", $room_id, $room_id);
        $capacity_check->execute();
        $room_data = $capacity_check->get_result()->fetch_assoc();

        if ($room_data['current_count'] >= $room_data['capacity']) {
            $message = "This room is already full (capacity: {$room_data['capacity']}).";
        } else {
            // Assign tenant
            $stmt = $conn->prepare("INSERT INTO tenant_rooms (tenant_id, room_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $tenant_id, $room_id);
            if ($stmt->execute()) {
                $message = "Room assigned successfully!";
            } else {
                $message = "Failed to assign room.";
            }
        }
    }
}

// ✅ Handle Unassign Tenant
if (isset($_POST['unassign_room'])) {
    $tenant_id = $_POST['tenant_id'];
    $room_id   = $_POST['room_id'];

    $stmt = $conn->prepare("DELETE FROM tenant_rooms WHERE tenant_id=? AND room_id=?");
    $stmt->bind_param("ii", $tenant_id, $room_id);
    if ($stmt->execute()) {
        $message = "Tenant unassigned from room successfully!";
    } else {
        $message = "Failed to unassign tenant.";
    }
}

// ✅ Fetch tenants & rooms
$tenants = $conn->query("SELECT id, fullname FROM tenants ORDER BY fullname ASC");
$all_rooms = $conn->query("
    SELECT r.*, COUNT(tr.id) AS tenants 
    FROM rooms r
    LEFT JOIN tenant_rooms tr ON r.id = tr.room_id
    GROUP BY r.id
    ORDER BY r.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Room Management — HouseMaster</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <?php include("navbar.php"); ?>
  <div class="main p-4">
    <h3 class="fw-bold text-dark mb-3">🏠 Room Management</h3>

    <?php if (!empty($message)): ?>
      <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>

    <!-- Add Room -->
    <div class="card shadow-sm border-0 mb-4">
      <div class="card-header bg-primary text-white">Add Room</div>
      <div class="card-body">
        <form method="POST">
          <div class="row g-3">
            <div class="col-md-4">
              <label>Room Label</label>
              <input type="text" name="room_label" class="form-control" placeholder="e.g. Dorm A - Room 1" required>
            </div>
            <div class="col-md-4">
              <label>Capacity</label>
              <input type="number" name="capacity" class="form-control" min="1" required>
            </div>
            <div class="col-md-4">
              <label>Rental Rate (₱)</label>
              <input type="number" step="0.01" name="rental_rate" class="form-control" required>
            </div>
          </div>
          <button type="submit" name="add_room" class="btn btn-success mt-3">Add Room</button>
        </form>
      </div>
    </div>

    <!-- Assign Tenant -->
    <div class="card shadow-sm border-0 mb-4">
      <div class="card-header bg-success text-white">Assign Tenant to Room</div>
      <div class="card-body">
        <form method="POST">
          <div class="row g-3">
            <div class="col-md-6">
              <label>Select Tenant</label>
              <select name="tenant_id" class="form-control" required>
                <option value="">-- Choose Tenant --</option>
                <?php while ($t = $tenants->fetch_assoc()): ?>
                  <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['fullname']); ?></option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label>Select Room</label>
              <select name="room_id" class="form-control" required>
                <option value="">-- Choose Room --</option>
                <?php
                $rooms_for_select = $conn->query("SELECT * FROM rooms ORDER BY room_label ASC");
                while ($r = $rooms_for_select->fetch_assoc()): ?>
                  <option value="<?php echo $r['id']; ?>"><?php echo htmlspecialchars($r['room_label']); ?></option>
                <?php endwhile; ?>
              </select>
            </div>
          </div>
          <button type="submit" name="assign_room" class="btn btn-primary mt-3">Assign</button>
        </form>
      </div>
    </div>

    <!-- All Rooms -->
    <div class="card shadow-sm border-0">
      <div class="card-header bg-dark text-white">All Rooms</div>
      <div class="card-body table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>Room Label</th>
              <th>Capacity</th>
              <th>Rental Rate</th>
              <th>Assigned Tenants</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($row = $all_rooms->fetch_assoc()): ?>
              <tr>
                <td><?php echo htmlspecialchars($row['room_label']); ?></td>
                <td><?php echo $row['capacity']; ?></td>
                <td>₱<?php echo number_format($row['rental_rate'], 2); ?></td>
                <td>
                  <?php
                  $tenant_list = $conn->query("
                      SELECT t.id, t.fullname 
                      FROM tenants t
                      INNER JOIN tenant_rooms tr ON t.id = tr.tenant_id
                      WHERE tr.room_id = {$row['id']}
                  ");
                  if ($tenant_list->num_rows > 0) {
                      while ($t = $tenant_list->fetch_assoc()): ?>
                        <form method="POST" class="d-inline">
                          <input type="hidden" name="tenant_id" value="<?php echo $t['id']; ?>">
                          <input type="hidden" name="room_id" value="<?php echo $row['id']; ?>">
                          <span class="badge bg-secondary"><?php echo htmlspecialchars($t['fullname']); ?></span>
                          <button type="submit" name="unassign_room" class="btn btn-sm btn-outline-danger ms-1">Unassign</button>
                        </form>
                      <?php endwhile;
                  } else {
                      echo '<span class="text-muted">No tenants</span>';
                  }
                  ?>
                </td>
                <td>
                  <a href="room_rules.php?room_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary">Manage Rules</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
