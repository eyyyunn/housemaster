<?php
include __DIR__ . "/../config.php";

if (!isset($_GET['room_id'])) {
    die("Room not specified.");
}

$room_id = intval($_GET['room_id']);

// Add new rule
if (isset($_POST['add_rule'])) {
    $rule_text = $_POST['rule_text'];
    $stmt = $conn->prepare("INSERT INTO room_rules (room_id, rule_text) VALUES (?, ?)");
    $stmt->bind_param("is", $room_id, $rule_text);
    $stmt->execute();
}

// Delete rule
if (isset($_POST['delete_rule'])) {
    $rule_id = $_POST['rule_id'];
    $stmt = $conn->prepare("DELETE FROM room_rules WHERE id=?");
    $stmt->bind_param("i", $rule_id);
    $stmt->execute();
}

// Fetch rules
$rules = $conn->query("SELECT * FROM room_rules WHERE room_id=$room_id ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Room Rules</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">


  <h3 class="mb-3">Manage Rules for Room <?php echo $room_id; ?></h3>

  <form method="POST" class="mb-3">
    <textarea name="rule_text" class="form-control mb-2" placeholder="Enter new rule..." required></textarea>
    <button type="submit" name="add_rule" class="btn btn-primary">Add Rule</button>
  </form>

  <ul class="list-group">
    <?php while ($rule = $rules->fetch_assoc()): ?>
      <li class="list-group-item d-flex justify-content-between">
        <?php echo htmlspecialchars($rule['rule_text']); ?>
        <form method="POST" class="d-inline">
          <input type="hidden" name="rule_id" value="<?php echo $rule['id']; ?>">
          <button type="submit" name="delete_rule" class="btn btn-sm btn-danger">Delete</button>
        </form>
      </li>
    <?php endwhile; ?>
  </ul>
</body>
</html>
