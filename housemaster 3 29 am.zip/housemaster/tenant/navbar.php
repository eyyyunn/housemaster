<nav class="navbar navbar-expand-lg" style="background-color: #05445E;">
  <div class="container-fluid">
    <!-- Branding -->
    <a class="navbar-brand text-white fw-bold" href="dashboard.php">
      <i class="fas fa-home"></i> HOUSE MASTER
    </a>

    <!-- Toggle for mobile -->
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#tenantNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar Links -->
    <div class="collapse navbar-collapse justify-content-end" id="tenantNavbar">
      <ul class="navbar-nav text-center">
        <li class="nav-item mx-3">
          <a class="nav-link text-white" href="dashboard.php">
            <i class="fas fa-home fa-lg d-block"></i>
            <small>Dashboard</small>
          </a>
        </li>
        <li class="nav-item mx-3">
          <a class="nav-link text-white" href="tenant-room.php">
            <i class="fas fa-door-open fa-lg d-block"></i>
            <small>My Room</small>
          </a>
        </li>
        <li class="nav-item mx-3">
          <a class="nav-link text-white" href="payment.php">
            <i class="fas fa-credit-card fa-lg d-block"></i>
            <small>Payment</small>
          </a>
        </li>
        <li class="nav-item mx-3">
          <a class="nav-link text-white" href="tenant-announcement.php">
            <i class="fas fa-bell fa-lg d-block"></i>
            <small>Announcement</small>
          </a>
        </li>
        <li class="nav-item mx-3">
          <a class="nav-link text-white" href="tenant-logout.php">
            <i class="fas fa-sign-out-alt fa-lg d-block"></i>
            <small>Logout</small>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
