<?php
session_start();
include __DIR__ . "/../config.php";

// ✅ Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}

$tenant_id = $_SESSION["tenant_id"];

// ✅ Fetch tenant’s room assignment
$sql = "
    SELECT r.id AS room_id, r.room_label, r.capacity, r.rental_rate, tr.assigned_at
    FROM tenant_rooms tr
    INNER JOIN rooms r ON tr.room_id = r.id
    WHERE tr.tenant_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tenant_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

// ✅ Calculate duration of stay
$duration = null;
if ($room && $room['assigned_at']) {
    $assigned_date = new DateTime($room['assigned_at']);
    $now = new DateTime();
    $interval = $assigned_date->diff($now);
    $duration = $interval->y > 0 
        ? $interval->y . " year(s)" 
        : ($interval->m > 0 ? $interval->m . " month(s)" : $interval->d . " day(s)");
}

// ✅ Fetch room rules if room exists
$rules = [];
if ($room) {
    $rule_query = $conn->prepare("SELECT rule_text FROM room_rules WHERE room_id = ?");
    $rule_query->bind_param("i", $room['room_id']);
    $rule_query->execute();
    $rules = $rule_query->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Room — HouseMaster</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>
  <!-- Navbar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="container my-4">
    <h3 class="fw-bold text-dark mb-4 text-center">My Room</h3>

    <div class="row g-4">
      <!-- Room Information -->
      <div class="col-lg-8">
        <div class="card shadow-sm border-0">
          <div class="card-header bg-primary text-white fw-bold">Room Information</div>
          <div class="card-body p-0">
            <table class="table table-bordered mb-0">
              <tbody>
                <?php if ($room): ?>
                  <tr>
                    <th scope="row">Room Label</th>
                    <td><?php echo htmlspecialchars($room['room_label']); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Capacity</th>
                    <td><?php echo htmlspecialchars($room['capacity']); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Monthly Rent</th>
                    <td>₱<?php echo number_format($room['rental_rate'], 2); ?> / Month</td>
                  </tr>
                  <tr>
                    <th scope="row">Move-in Date</th>
                    <td><?php echo date("M d, Y", strtotime($room['assigned_at'])); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Duration of Stay</th>
                    <td><?php echo $duration ?: "N/A"; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Current Status</th>
                    <td><span class="badge bg-success">Occupied</span></td>
                  </tr>
                <?php else: ?>
                  <tr>
                    <td colspan="2" class="text-center text-muted">No room assigned yet.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

        <!-- Right Column -->
      <div class="col-lg-4">
      <!-- House Rules -->
      <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-primary text-white fw-bold">House Rules & Reminders</div>
        <div class="card-body">
          <ul class="mb-0">
            <?php if ($room && $rules->num_rows > 0): ?>
              <?php while ($rule = $rules->fetch_assoc()): ?>
                <?php 
                  $lines = preg_split('/\r\n|\r|\n/', $rule['rule_text']); 
                  foreach ($lines as $line): 
                ?>
                  <li><?php echo htmlspecialchars(trim($line)); ?></li>
                <?php endforeach; ?>
              <?php endwhile; ?>
            <?php elseif ($room): ?>
              <li class="text-muted">No rules set for this room.</li>
            <?php else: ?>
              <li class="text-muted">No room assigned.</li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <!-- Maintenance -->
      <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white fw-bold">Maintenance & Requests</div>
        <div class="card-body">
          <p class="mb-2"><strong>Last Maintenance Check:</strong> <?php echo date("M Y"); ?></p>
          <button class="btn btn-danger w-100">Report an Issue</button>
        </div>
      </div>
      </div>

    </div>
  </div>

  <footer class="text-center mt-5 mb-3 text-muted">
    HouseMaster © 2025 — Boarding House & Dormitory Management System
  </footer>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
