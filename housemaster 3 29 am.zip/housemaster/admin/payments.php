<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Payments</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark">💵 Payments</h3>
    <div class="card shadow-sm border-0 mt-3">
      <div class="card-body">
        <table class="table table-striped align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Tenant</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Method</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>John Doe</td>
              <td>₱5,000</td>
              <td>2025-03-01</td>
              <td>GCash</td>
              <td><span class="badge bg-success">Paid</span></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Maria Santos</td>
              <td>₱5,000</td>
              <td>2025-03-03</td>
              <td>Cash</td>
              <td><span class="badge bg-danger">Unpaid</span></td>
            </tr>
            <tr>
              <td>3</td>
              <td>Carlos Reyes</td>
              <td>₱5,000</td>
              <td>2025-03-05</td>
              <td>Bank Transfer</td>
              <td><span class="badge bg-warning text-dark">Pending</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>
</body>
</html>
