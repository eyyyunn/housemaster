<?php
session_start();
include __DIR__ . "/../config.php";

// ✅ Require admin to be logged in
if (!isset($_SESSION["admin"])) {
    header("Location: admin-login.php");
    exit();
}

// ✅ Fetch data from database
$tenantsCount = $conn->query("SELECT COUNT(*) AS total FROM tenants")->fetch_assoc()["total"];
$roomsCount = $conn->query("SELECT COUNT(*) AS total FROM rooms")->fetch_assoc()["total"];
$paymentsTotal = $conn->query("SELECT IFNULL(SUM(amount),0) AS total FROM payments WHERE status='paid'")
                      ->fetch_assoc()["total"];
$noticesCount = $conn->query("SELECT COUNT(*) AS total FROM notices")->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <?php include("navbar.php"); ?>

  <div class="main">
    <h3 class="fw-bold text-dark">📊 Dashboard</h3>
    <div class="row mt-3">
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Tenants</h5>
            <p class="display-6 fw-bold text-primary"><?php echo $tenantsCount; ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Rooms</h5>
            <p class="display-6 fw-bold text-success"><?php echo $roomsCount; ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Payments</h5>
            <p class="display-6 fw-bold text-warning">₱<?php echo number_format($paymentsTotal, 0); ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Notices</h5>
            <p class="display-6 fw-bold text-danger"><?php echo $noticesCount; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
