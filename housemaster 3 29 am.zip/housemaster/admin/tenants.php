<?php
include __DIR__ . "/../config.php";

// Handle status filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : "";

// Build query with filter
$sql = "
    SELECT t.id, t.fullname, t.email, t.phone, t.status, t.created_at, r.room_label
    FROM tenants t
    LEFT JOIN tenant_rooms tr ON t.id = tr.tenant_id
    LEFT JOIN rooms r ON tr.room_id = r.id
";

if (!empty($status_filter)) {
    $sql .= " WHERE t.status = '" . $conn->real_escape_string($status_filter) . "'";
}

$sql .= " ORDER BY t.fullname ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Tenants Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main p-4">
    <h3 class="fw-bold text-dark">👥 Tenants Profile</h3>

    <!-- Filter -->
    <form method="GET" class="mb-3">
      <div class="row g-2">
        <div class="col-md-3">
          <select name="status" class="form-select">
            <option value="">-- Filter by Status --</option>
            <option value="active" <?php if ($status_filter=="active") echo "selected"; ?>>Active</option>
            <!-- <option value="pending" <?php if ($status_filter=="pending") echo "selected"; ?>>Pending</option>
            <option value="inactive" <?php if ($status_filter=="inactive") echo "selected"; ?>>Inactive</option> -->
            <option value="unassigned" <?php if ($status_filter=="unassigned") echo "selected"; ?>>Unassigned</option>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Apply</button>
        </div>
        <div class="col-md-2">
          <a href="tenants.php" class="btn btn-secondary w-100">Reset</a>
        </div>
      </div>
    </form>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Room</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result->num_rows > 0): ?>
              <?php $i=1; while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                  <td><?php echo $row['room_label'] ? htmlspecialchars($row['room_label']) : '<span class="text-muted">Unassigned</span>'; ?></td>
                  <td><?php echo htmlspecialchars($row['phone']); ?></td>
                  <td><?php echo htmlspecialchars($row['email']); ?></td>
                  <td>
                    <?php
                      $status = $row['status'];
                      $badgeClass = match($status) {
                          "active" => "success",
                          "pending" => "warning",
                          "inactive" => "danger",
                          "unassigned" => "secondary",
                          default => "dark"
                      };
                    ?>
                    <span class="badge bg-<?php echo $badgeClass; ?>"><?php echo ucfirst($status); ?></span>
                  </td>
                  <td>
                    <!-- Modal Trigger -->
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#tenant<?php echo $row['id']; ?>">View Details</button>
                  </td>
                </tr>

                <!-- Tenant Modal -->
                <div class="modal fade" id="tenant<?php echo $row['id']; ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Tenant Details — <?php echo htmlspecialchars($row['fullname']); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                      </div>
                      <div class="modal-body">
                        <p><b>Name:</b> <?php echo htmlspecialchars($row['fullname']); ?></p>
                        <p><b>Room:</b> <?php echo $row['room_label'] ? htmlspecialchars($row['room_label']) : 'Unassigned'; ?></p>
                        <p><b>Contact:</b> <?php echo htmlspecialchars($row['phone']); ?></p>
                        <p><b>Email:</b> <?php echo htmlspecialchars($row['email']); ?></p>
                        <p><b>Status:</b> <?php echo ucfirst($row['status']); ?></p>
                        <p><b>Joined:</b> <?php echo date("M d, Y", strtotime($row['created_at'])); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="7" class="text-center text-muted">No tenants found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
