<!-- navbar.php -->
<div class="sidebar">
  <div class="logo-hold">
    <!-- <img class="logo"  src="../assets/img/logo.webp" alt="" srcset=""> -->
    <h2 class="name">HOUSE MASTER</h2>
</div>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
  <a href="tenants.php"><i class="fas fa-users"></i> Tenants Profile</a>
  <a href="rooms.php"><i class="fas fa-home"></i> Room Management</a>
  <a href="bills.php"><i class="fas fa-file-invoice"></i> Utility Bills</a>
  <a href="payments.php"><i class="fas fa-money-bill"></i> Payments</a>
  <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
  <a href="notices.php"><i class="fas fa-bell"></i> Notice Board</a>
  <a href="suggestions.php"><i class="fas fa-comment-dots"></i> Suggestions</a>
  <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>
