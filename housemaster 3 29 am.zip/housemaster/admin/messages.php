<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Messages</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark">✉️ Messages</h3>
    <div class="card shadow-sm border-0 mt-3">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item"><b>John Doe:</b> Requesting maintenance in Dorm A - Room 1.</li>
          <li class="list-group-item"><b>Maria Santos:</b> Asking about payment deadline.</li>
          <li class="list-group-item"><b>Carlos Reyes:</b> Internet connection issue in Dorm C.</li>
        </ul>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>
</body>
</html>
