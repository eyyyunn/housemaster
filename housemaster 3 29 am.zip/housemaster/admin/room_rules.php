<?php
include __DIR__ . "/../config.php";
$room_id = intval($_GET['room_id']);

// Add rule
if (isset($_POST['add_rule'])) {
    $rule_text = trim($_POST['rule_text']);
    if ($rule_text !== '') {
        $stmt = $conn->prepare("INSERT INTO room_rules (room_id, rule_text) VALUES (?, ?)");
        $stmt->bind_param("is", $room_id, $rule_text);
        $stmt->execute();
    }
}

// Delete rule
if (isset($_POST['delete_rule'])) {
    $rule_id = intval($_POST['rule_id']);
    $stmt = $conn->prepare("DELETE FROM room_rules WHERE id=? AND room_id=?");
    $stmt->bind_param("ii", $rule_id, $room_id);
    $stmt->execute();
}

// Fetch rules
$stmt = $conn->prepare("SELECT * FROM room_rules WHERE room_id=? ORDER BY created_at DESC");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$rules_result = $stmt->get_result();
?>

<form id="addRuleForm">
    <div class="mb-3">
        <textarea name="rule_text" class="form-control" placeholder="Enter new rule..." required></textarea>
    </div>
    <button type="submit" name="add_rule" class="btn btn-primary">Add Rule</button>
</form>

<hr>

<ul class="list-group" id="ruleList">
<?php while ($rule = $rules_result->fetch_assoc()): ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <?php echo htmlspecialchars($rule['rule_text']); ?>
        <button class="btn btn-sm btn-danger delete-rule" data-id="<?php echo $rule['id']; ?>">Delete</button>
    </li>
<?php endwhile; ?>
</ul>
