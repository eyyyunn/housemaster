<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Notice Board</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
<?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark">🔔 Notice Board</h3>

    <!-- Notice Configuration Form -->
    <div class="card shadow-sm border-0 mt-3">
      <div class="card-header bg-primary text-white">
        Compose New Notice
      </div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="noticeTitle" class="form-label">Notice Title</label>
            <input type="text" class="form-control" id="noticeTitle" placeholder="Enter notice title">
          </div>
          <div class="mb-3">
            <label for="noticeBody" class="form-label">Notice Body</label>
            <textarea class="form-control" id="noticeBody" rows="4" placeholder="Enter notice details"></textarea>
          </div>
          <div class="mb-3">
            <label for="noticeDate" class="form-label">Date</label>
            <input type="date" class="form-control" id="noticeDate">
          </div>
          <button type="submit" class="btn btn-success"><i class="fas fa-paper-plane"></i> Post Notice</button>
        </form>
      </div>
    </div>

    <!-- Existing Notices -->
    <div class="card shadow-sm border-0 mt-4">
      <div class="card-header bg-secondary text-white">
        Posted Notices
      </div>
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">
            <b>General Cleaning</b> <br>
            <small class="text-muted">Posted on: Mar 10, 2025</small>
            <p>General cleaning scheduled at Dorm A. All tenants are advised to cooperate.</p>
          </li>
          <li class="list-group-item">
            <b>Water Maintenance</b> <br>
            <small class="text-muted">Posted on: Mar 15, 2025</small>
            <p>Water supply will be unavailable from 9AM to 5PM due to maintenance.</p>
          </li>
          <li class="list-group-item">
            <b>Fire Drill</b> <br>
            <small class="text-muted">Posted on: Mar 20, 2025</small>
            <p>Mandatory fire drill will be conducted for all dormitories.</p>
          </li>
        </ul>
      </div>
    </div>

    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
