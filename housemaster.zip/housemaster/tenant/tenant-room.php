<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — My Room</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>
  <!-- Tenant Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="tenant-dashboard.php">🏠 HouseMaster</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTenant">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTenant">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link active" href="tenant-room.php">My Room</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-payment.php">Payment</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-announcement.php">Announcement</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-support.php">Support</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark mt-3">🛏️ My Room</h3>

    <div class="card shadow-sm border-0 mt-4">
      <div class="card-body">
        <h5 class="card-title">Room Information</h5>
        <table class="table table-bordered mt-3">
          <tbody>
            <tr>
              <th scope="row">Room Number</th>
              <td>Dorm A - Room 1</td>
            </tr>
            <tr>
              <th scope="row">Capacity</th>
              <td>4</td>
            </tr>
            <tr>
              <th scope="row">Assigned Roommates</th>
              <td>
                <ul class="mb-0">
                  <li>Maria Santos</li>
                  <li>Carlos Reyes</li>
                  <li>Ana Cruz</li>
                </ul>
              </td>
            </tr>
            <tr>
              <th scope="row">Rental Rate</th>
              <td>₱5,000 / month</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Room Notices -->
    <div class="card shadow-sm border-0 mt-4">
      <div class="card-body">
        <h5 class="card-title">Room Notices</h5>
        <ul class="list-group">
          <li class="list-group-item">🔧 Maintenance scheduled on March 28 at 2 PM</li>
          <li class="list-group-item">🧹 General cleaning every Saturday at 9 AM</li>
          <li class="list-group-item">⚡ Power outage notice: March 30, 9 AM - 5 PM</li>
        </ul>
      </div>
    </div>
  </div>

  <footer>HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
