<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Support</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
  <style>
    /* Extra chat styling */
    .chat-box {
      max-height: 400px;
      overflow-y: auto;
      padding: 15px;
      background: #fff;
      border-radius: 10px;
      border: 1px solid #ddd;
    }
    .chat-message {
      margin-bottom: 15px;
    }
    .chat-message.admin {
      text-align: left;
    }
    .chat-message.tenant {
      text-align: right;
    }
    .chat-bubble {
      display: inline-block;
      padding: 10px 15px;
      border-radius: 15px;
      max-width: 70%;
    }
    .chat-bubble.admin {
      background: #e9ecef;
      color: #333;
    }
    .chat-bubble.tenant {
      background: #05445E;
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Tenant Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="tenant-dashboard.php">🏠 HouseMaster</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTenant">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTenant">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-room.php">My Room</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-payment.php">Payment</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-announcement.php">Announcement</a></li>
          <li class="nav-item"><a class="nav-link active" href="tenant-support.php">Support</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark mt-3">💬 Support — Chat with Admin</h3>

    <div class="card shadow-sm border-0 mt-4">
      <div class="card-body">
        <!-- Chat History -->
        <div class="chat-box mb-3">
          <div class="chat-message admin">
            <div class="chat-bubble admin">Hello John, how can I help you today?</div>
          </div>
          <div class="chat-message tenant">
            <div class="chat-bubble tenant">Hi Admin, I have an issue with the water supply.</div>
          </div>
          <div class="chat-message admin">
            <div class="chat-bubble admin">Noted. We will schedule a plumber this afternoon.</div>
          </div>
        </div>

        <!-- Chat Input -->
        <form class="d-flex">
          <input type="text" class="form-control me-2" placeholder="Type your message...">
          <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
        </form>
      </div>
    </div>
  </div>

  <footer>HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
