<?php
session_start();
include __DIR__ . "/../config.php"; // go up one level to load config

// ✅ Handle Login
if (isset($_POST["login"])) {
    $email = $_POST["login_email"];
    $password = $_POST["login_password"];

    $stmt = $conn->prepare("SELECT * FROM tenants WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $tenant = $result->fetch_assoc();
        if (password_verify($password, $tenant["password"])) {
            $_SESSION["tenant_id"] = $tenant["id"];   // store tenant ID
            $_SESSION["tenant_name"] = $tenant["fullname"]; // optional: store name
            header("Location: dashboard.php");
            exit();
        } else {
            $login_error = "Invalid password!";
        }
    } else {
        $login_error = "No account found with that email!";
    }
}

// ✅ Handle Signup
if (isset($_POST["signup"])) {
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $age = $_POST["age"];
    $phone = $_POST["phone"];

    // Insert new tenant
    $stmt = $conn->prepare("INSERT INTO tenants (fullname, email, password,  age, phone) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $fullname, $email, $password,  $age, $phone);

    if ($stmt->execute()) {
        $newTenantId = $stmt->insert_id;
        $_SESSION["tenant_id"] = $newTenantId;
        $_SESSION["tenant_name"] = $fullname;
        header("Location: dashboard.php");
        exit();
    } else {
        $signup_error = "Sign up failed. Email may already be registered.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Tenant Auth</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <style>
    body {
      background: #f5f7fa;
      font-family: 'Segoe UI', sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .auth-wrapper {
      width: 950px;
      height: 580px;
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      display: flex;
      overflow: hidden;
    }
    .auth-left {
      width: 50%;
      position: relative;
      overflow: hidden;
    }
    .form-slide {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      padding: 40px;
      transition: transform 0.6s ease-in-out;
    }
    .login-panel { z-index: 2; }
    .signup-panel { transform: translateX(100%); z-index: 1; }
    .auth-wrapper.show-signup .login-panel { transform: translateX(-100%); }
    .auth-wrapper.show-signup .signup-panel { transform: translateX(0); z-index: 2; }
    .step { display: none; }
    .step.active { display: block; }
    .auth-branding {
      width: 50%;
      background: linear-gradient(135deg, #05445E, #189AB4);
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 40px;
    }
    .auth-branding h1 { font-size: 2rem; font-weight: bold; }
    .btn-primary { background: #05445E; border: none; }
    .btn-primary:hover { background: #032f40; }
    .btn-success { background: #189AB4; border: none; }
    .btn-success:hover { background: #107484; }
    a { color: #05445E; text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="auth-wrapper" id="authBox">
    <!-- Left: Forms -->
    <div class="auth-left">
      <!-- Login -->
      <div class="form-slide login-panel">
        <h3 class="fw-bold mb-3">Tenant Login</h3>
        <?php if (!empty($login_error)) : ?>
          <div class="alert alert-danger"><?php echo $login_error; ?></div>
        <?php endif; ?>
        <form method="POST">
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="login_email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="login_password" class="form-control" required>
          </div>
          <button type="submit" name="login" class="btn btn-primary w-100 mb-3">Login</button>
          <p class="text-center">Don’t have an account? <a href="#" onclick="toggleSignup()">Sign Up</a></p>
        </form>
      </div>

      <!-- Signup -->
      <div class="form-slide signup-panel">
        <h3 class="fw-bold mb-3">Tenant Sign Up</h3>
        <?php if (!empty($signup_error)) : ?>
          <div class="alert alert-danger"><?php echo $signup_error; ?></div>
        <?php endif; ?>
        <form method="POST">
          <!-- Step 1 -->
          <div class="step active" id="step1">
            <div class="mb-3"><label>Full Name</label><input type="text" name="fullname" class="form-control" required></div>
            <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
            <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
            <button type="button" class="btn btn-primary w-100" onclick="nextStep()">Next</button>
            <p class="text-center mt-3"><a href="#" onclick="toggleSignup()">Back to Login</a></p>
          </div>
          <!-- Step 2 -->
          <div class="step" id="step2">
            
            <div class="mb-3"><label>Age</label><input type="number" name="age" class="form-control" required></div>
            <div class="mb-3"><label>Phone</label><input type="text" name="phone" class="form-control" required></div>
            <button type="button" class="btn btn-secondary w-100 mb-2" onclick="prevStep()">Back</button>
            <button type="submit" name="signup" class="btn btn-success w-100">Sign Up</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Right: Branding -->
    <div class="auth-branding">
      <h1>🏠 HouseMaster</h1>
      <p>Boarding House & Dormitory Management System</p>
    </div>
  </div>

  <script>
    const authBox = document.getElementById("authBox");
    function toggleSignup() {
      authBox.classList.toggle("show-signup");
      document.getElementById("step1").classList.add("active");
      document.getElementById("step2").classList.remove("active");
    }
    function nextStep() {
      document.getElementById("step1").classList.remove("active");
      document.getElementById("step2").classList.add("active");
    }
    function prevStep() {
      document.getElementById("step2").classList.remove("active");
      document.getElementById("step1").classList.add("active");
    }
  </script>
</body>
</html>
