<?php
session_start();
include __DIR__ . "/../config.php";  // config is outside /tenant folder

// ✅ Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}

$tenant_id = $_SESSION["tenant_id"];

// ✅ Fetch tenant info
$tenant = $conn->query("SELECT * FROM tenants WHERE id=$tenant_id")->fetch_assoc();

// ✅ Fetch room assignment (if exists)
$room = $conn->query("
    SELECT * FROM rooms 
    WHERE id IN (SELECT room_id FROM tenant_rooms WHERE tenant_id=$tenant_id)
")->fetch_assoc();

// ✅ Next due payment
$payment = $conn->query("
    SELECT * FROM payments 
    WHERE tenant_id=$tenant_id 
    ORDER BY due_date ASC 
    LIMIT 1
")->fetch_assoc();

// ✅ Recent notices (last 3)
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC LIMIT 3");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Tenant Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>
  <!-- Tenant Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="dashboard.php">🏠 HouseMaster</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTenant">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTenant">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-room.php">My Room</a></li>
          <li class="nav-item"><a class="nav-link" href="payment.php">Payment</a></li>
          <li class="nav-item"><a class="nav-link" href="announcement.php">Announcement</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-support.php">Support</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Dashboard Content -->
  <div class="main">
    <h3 class="fw-bold text-dark mt-3">👋 Welcome, <?php echo htmlspecialchars($tenant["fullname"]); ?>!</h3>

    <div class="row mt-4">
      <!-- Room Status -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0 text-center">
          <div class="card-body">
            <h5 class="card-title">My Room</h5>
            <?php if ($room): ?>
              <p class="fs-4 fw-bold text-primary"><?php echo htmlspecialchars($room["room_number"]); ?></p>
              <p class="text-muted">Capacity: <?php echo $room["capacity"]; ?> | Rate: ₱<?php echo number_format($room["rental_rate"]); ?></p>
            <?php else: ?>
              <p class="text-muted">No room assigned yet.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Next Due Payment -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0 text-center">
          <div class="card-body">
            <h5 class="card-title">Next Due Payment</h5>
            <?php if ($payment): ?>
              <p class="fs-4 fw-bold text-warning">₱<?php echo number_format($payment["amount"]); ?></p>
              <p class="text-muted">Due: <?php echo $payment["due_date"]; ?></p>
              <p>Status: 
                <span class="badge bg-<?php echo $payment["status"] === 'paid' ? 'success' : 'danger'; ?>">
                  <?php echo ucfirst($payment["status"]); ?>
                </span>
              </p>
            <?php else: ?>
              <p class="text-muted">No upcoming payments.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Notifications -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Latest Notices</h5>
            <ul class="list-group list-group-flush">
              <?php if ($notices->num_rows > 0): ?>
                <?php while ($notice = $notices->fetch_assoc()): ?>
                  <li class="list-group-item">
                    <strong><?php echo htmlspecialchars($notice["title"]); ?></strong><br>
                    <small class="text-muted"><?php echo date("M d, Y", strtotime($notice["created_at"])); ?></small>
                  </li>
                <?php endwhile; ?>
              <?php else: ?>
                <li class="list-group-item text-muted">No new notices</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <footer class="text-center mt-5 mb-3 text-muted">
    HouseMaster © 2025 — Boarding House & Dormitory Management System
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
