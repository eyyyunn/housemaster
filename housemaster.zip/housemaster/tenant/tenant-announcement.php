<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Announcements</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>
  <!-- Tenant Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="tenant-dashboard.php">🏠 HouseMaster</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTenant">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTenant">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-room.php">My Room</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-payment.php">Payment</a></li>
          <li class="nav-item"><a class="nav-link active" href="tenant-announcement.php">Announcement</a></li>
          <li class="nav-item"><a class="nav-link" href="tenant-support.php">Support</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark mt-3">📢 Announcements</h3>

    <div class="card shadow-sm border-0 mt-4">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">
            <h6 class="fw-bold mb-1">General Cleaning</h6>
            <small class="text-muted">Posted on: March 20, 2025</small>
            <p class="mt-2 mb-0">General cleaning is scheduled this Saturday at 9 AM. All tenants are advised to participate.</p>
          </li>
          <li class="list-group-item">
            <h6 class="fw-bold mb-1">Water Maintenance</h6>
            <small class="text-muted">Posted on: March 18, 2025</small>
            <p class="mt-2 mb-0">Water supply will be unavailable from 9 AM to 5 PM due to maintenance.</p>
          </li>
          <li class="list-group-item">
            <h6 class="fw-bold mb-1">Fire Drill</h6>
            <small class="text-muted">Posted on: March 10, 2025</small>
            <p class="mt-2 mb-0">Mandatory fire drill will be conducted at Dorm A and Dorm B. Please assemble at the main hall.</p>
          </li>
        </ul>
      </div>
    </div>
  </div>

  <footer>HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
