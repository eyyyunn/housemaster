<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Messages</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h2>🏠 HouseMaster</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="tenants.php"><i class="fas fa-users"></i> Tenants Profile</a>
    <a href="rooms.php" class=""><i class="fas fa-home"></i> Room Management</a>
    <a href="bills.php"><i class="fas fa-file-invoice"></i> Utility Bills</a>
    <a href="payments.php"><i class="fas fa-money-bill"></i> Payments</a>
    <a href="messages.php" class="active"><i class="fas fa-envelope"></i> Messages</a>
    <a href="notices.php"><i class="fas fa-bell"></i> Notice Board</a>
    <a href="suggestions.php"><i class="fas fa-comment-dots"></i> Suggestions</a>
  </div>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark">✉️ Messages</h3>
    <div class="card shadow-sm border-0 mt-3">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item"><b>John Doe:</b> Requesting maintenance in Dorm A - Room 1.</li>
          <li class="list-group-item"><b>Maria Santos:</b> Asking about payment deadline.</li>
          <li class="list-group-item"><b>Carlos Reyes:</b> Internet connection issue in Dorm C.</li>
        </ul>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>
</body>
</html>
