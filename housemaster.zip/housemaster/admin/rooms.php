<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Room Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h2>🏠 HouseMaster</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="tenants.php"><i class="fas fa-users"></i> Tenants Profile</a>
    <a href="rooms.php" class="active"><i class="fas fa-home"></i> Room Management</a>
    <a href="bills.php"><i class="fas fa-file-invoice"></i> Utility Bills</a>
    <a href="payments.php"><i class="fas fa-money-bill"></i> Payments</a>
    <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <a href="notices.php"><i class="fas fa-bell"></i> Notice Board</a>
    <a href="suggestions.php"><i class="fas fa-comment-dots"></i> Suggestions</a>
  </div>

  <!-- Main Content -->
  <div class="main">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3 class="fw-bold text-dark">🏘️ Room Management</h3>
      <button class="btn btn-primary"><i class="fas fa-plus"></i> Add Room</button>
    </div>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Room Name</th>
              <th>Capacity</th>
              <th>Occupied</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Dorm A - Room 1</td>
              <td>4</td>
              <td>3</td>
              <td><span class="badge bg-success">Available</span></td>
              <td>
                <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-edit"></i></button>
                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td>Dorm B - Room 2</td>
              <td>6</td>
              <td>6</td>
              <td><span class="badge bg-danger">Full</span></td>
              <td>
                <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-edit"></i></button>
                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
            <tr>
              <td>3</td>
              <td>Dorm C - Room 3</td>
              <td>5</td>
              <td>2</td>
              <td><span class="badge bg-warning text-dark">Partially Filled</span></td>
              <td>
                <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-edit"></i></button>
                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
