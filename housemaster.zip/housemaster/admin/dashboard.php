<?php
session_start();
include __DIR__ . "/../config.php";

// ✅ Require admin to be logged in
if (!isset($_SESSION["admin"])) {
    header("Location: admin-login.php");
    exit();
}

// ✅ Fetch data from database
$tenantsCount = $conn->query("SELECT COUNT(*) AS total FROM tenants")->fetch_assoc()["total"];
$roomsCount = $conn->query("SELECT COUNT(*) AS total FROM rooms")->fetch_assoc()["total"];
$paymentsTotal = $conn->query("SELECT IFNULL(SUM(amount),0) AS total FROM payments WHERE status='paid'")
                      ->fetch_assoc()["total"];
$noticesCount = $conn->query("SELECT COUNT(*) AS total FROM notices")->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <div class="sidebar">
    <h2>🏠 HouseMaster</h2>
    <a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="tenants.php"><i class="fas fa-users"></i> Tenants Profile</a>
    <a href="rooms.php"><i class="fas fa-home"></i> Room Management</a>
    <a href="bills.php"><i class="fas fa-file-invoice"></i> Utility Bills</a>
    <a href="payments.php"><i class="fas fa-money-bill"></i> Payments</a>
    <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <a href="notices.php"><i class="fas fa-bell"></i> Notice Board</a>
    <a href="suggestions.php"><i class="fas fa-comment-dots"></i> Suggestions</a>
    <hr>
    <a href="admin-logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <div class="main">
    <h3 class="fw-bold text-dark">📊 Dashboard</h3>
    <div class="row mt-3">
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Tenants</h5>
            <p class="display-6 fw-bold text-primary"><?php echo $tenantsCount; ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Rooms</h5>
            <p class="display-6 fw-bold text-success"><?php echo $roomsCount; ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Payments</h5>
            <p class="display-6 fw-bold text-warning">₱<?php echo number_format($paymentsTotal, 0); ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-center shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title">Notices</h5>
            <p class="display-6 fw-bold text-danger"><?php echo $noticesCount; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
