<?php
session_start();
include __DIR__ . "/../config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === ADMIN_USER && $password === ADMIN_PASS) {
        $_SESSION["admin"] = ADMIN_USER;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "❌ Invalid admin credentials!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f7fa;
      font-family: 'Segoe UI', sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-box {
      width: 380px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      padding: 30px;
    }
    .login-box h3 {
      text-align: center;
      margin-bottom: 20px;
      color: #05445E;
      font-weight: bold;
    }
    .btn-primary {
      background: #05445E;
      border: none;
    }
    .btn-primary:hover {
      background: #032f40;
    }
    .logo {
      text-align: center;
      margin-bottom: 15px;
    }
    .logo span {
      font-size: 2rem;
      font-weight: bold;
      color: #189AB4;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <div class="logo">
      <span>🏠 HouseMaster</span>
    </div>
    <h3>Admin Login</h3>

    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger py-2"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" id="username" class="form-control" required autofocus>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" id="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
  </div>
</body>
</html>
