<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Tenants Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h2>🏠 HouseMaster</h2>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="tenants.php" class="active"><i class="fas fa-users"></i> Tenants Profile</a>
    <a href="rooms.php" class=""><i class="fas fa-home"></i> Room Management</a>
    <a href="bills.php"><i class="fas fa-file-invoice"></i> Utility Bills</a>
    <a href="payments.php"><i class="fas fa-money-bill"></i> Payments</a>
    <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <a href="notices.php"><i class="fas fa-bell"></i> Notice Board</a>
    <a href="suggestions.php"><i class="fas fa-comment-dots"></i> Suggestions</a>
  </div>

  <!-- Main Content -->
  <div class="main">
    <h3 class="fw-bold text-dark">👥 Tenants Profile</h3>
    <div class="card shadow-sm border-0 mt-3">
      <div class="card-body">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Room</th>
              <th>Contact</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>John Doe</td>
              <td>Dorm A - Room 1</td>
              <td>09171234567</td>
              <td><span class="badge bg-success">Active</span></td>
              <td><button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#tenant1">View Details</button></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Maria Santos</td>
              <td>Dorm B - Room 2</td>
              <td>09181234567</td>
              <td><span class="badge bg-warning">Pending</span></td>
              <td><button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#tenant2">View Details</button></td>
            </tr>
            <tr>
              <td>3</td>
              <td>Carlos Reyes</td>
              <td>Dorm C - Room 3</td>
              <td>09191234567</td>
              <td><span class="badge bg-danger">Inactive</span></td>
              <td><button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#tenant3">View Details</button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Tenant 1 Modal -->
    <div class="modal fade" id="tenant1" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Tenant Details — John Doe</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <p><b>Name:</b> John Doe</p>
            <p><b>Room:</b> Dorm A - Room 1</p>
            <p><b>Contact:</b> 09171234567</p>
            <p><b>Email:</b> john.doe@email.com</p>
            <p><b>Status:</b> Active</p>
            <p><b>Move-in Date:</b> Jan 10, 2024</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Tenant 2 Modal -->
    <div class="modal fade" id="tenant2" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Tenant Details — Maria Santos</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <p><b>Name:</b> Maria Santos</p>
            <p><b>Room:</b> Dorm B - Room 2</p>
            <p><b>Contact:</b> 09181234567</p>
            <p><b>Email:</b> maria.santos@email.com</p>
            <p><b>Status:</b> Pending</p>
            <p><b>Move-in Date:</b> Feb 5, 2024</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Tenant 3 Modal -->
    <div class="modal fade" id="tenant3" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Tenant Details — Carlos Reyes</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <p><b>Name:</b> Carlos Reyes</p>
            <p><b>Room:</b> Dorm C - Room 3</p>
            <p><b>Contact:</b> 09191234567</p>
            <p><b>Email:</b> carlos.reyes@email.com</p>
            <p><b>Status:</b> Inactive</p>
            <p><b>Move-in Date:</b> Mar 2, 2023</p>
          </div>
        </div>
      </div>
    </div>

    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
