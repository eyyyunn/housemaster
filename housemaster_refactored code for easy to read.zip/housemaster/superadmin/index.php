<?php
session_start();

// Check if the super admin is logged in, otherwise redirect to login page
if (!isset($_SESSION['super_admin_id'])) {
    header("Location: login.php");
    exit();
}

require_once '../config.php';

// ✅ Auto-update expired subscriptions to 'payment_due'
$conn->query("
    UPDATE admins a
    JOIN admin_subscriptions s ON a.id = s.admin_id
    SET a.account_status = 'payment_due', s.status = 'expired'
    WHERE s.end_date < CURDATE() AND a.account_status = 'active'
");

// Fetch all owners (admins) with subscription info
$result = $conn->query("
    SELECT a.id, a.name, a.email, a.boarding_code, a.account_status, a.created_at, a.payment_proof, a.payment_method, s.end_date 
    FROM admins a 
    LEFT JOIN admin_subscriptions s ON a.id = s.admin_id 
    ORDER BY a.created_at DESC
");
$owners = $result->fetch_all(MYSQLI_ASSOC);

// Filter pending owners for the notification area
$pending_owners = array_filter($owners, function($owner) {
    return $owner['account_status'] === 'pending';
});

// Filter non-pending owners for the main table
$non_pending_owners = array_filter($owners, function($owner) {
    return $owner['account_status'] !== 'pending';
});

// Get flash message from session for feedback
$flash_message = '';
if (isset($_SESSION['flash_message'])) {
    $flash_message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - HouseMaster</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Super Admin Panel</a>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </nav>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
             <h1>Manage Owners</h1>
        </div>

        <?php if ($flash_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $flash_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($pending_owners)): ?>
            <div class="card mb-4 border-info">
                <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-exclamation-circle-fill me-2"></i>Pending Verifications</h5>
                    <span class="badge bg-light text-info"><?php echo count($pending_owners); ?> Request(s)</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Boarding Code</th>
                                    <th>Payment Proof</th>
                                    <th>Date Registered</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_owners as $p_owner): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($p_owner['name']); ?></td>
                                        <td><?php echo htmlspecialchars($p_owner['email']); ?></td>
                                        <td><?php echo htmlspecialchars($p_owner['boarding_code']); ?></td>
                                        <td>
                                            <?php if (!empty($p_owner['payment_proof'])): ?>
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#proofModal<?php echo $p_owner['id']; ?>">
                                                    <img src="../assets/uploads/payment_proofs/<?php echo htmlspecialchars($p_owner['payment_proof']); ?>" alt="Proof" style="height: 40px; width: auto; border: 1px solid #ddd; border-radius: 4px;">
                                                </a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="proofModal<?php echo $p_owner['id']; ?>" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Payment Proof: <?php echo htmlspecialchars($p_owner['name']); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body text-center bg-light">
                                                                <img src="../assets/uploads/payment_proofs/<?php echo htmlspecialchars($p_owner['payment_proof']); ?>" class="img-fluid" alt="Payment Proof">
                                                                <p class="mt-2 text-muted">Method: <strong><?php echo htmlspecialchars(ucfirst($p_owner['payment_method'] ?? 'Unknown')); ?></strong></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">No Proof</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($p_owner['created_at'])); ?></td>
                                        <td class="text-end">
                                            <form action="update_owner_status.php" method="POST" class="d-inline">
                                                <input type="hidden" name="admin_id" value="<?php echo $p_owner['id']; ?>">
                                                <input type="hidden" name="account_status" value="active">
                                                <button type="submit" class="btn btn-success btn-sm"><i class="bi bi-check-lg"></i> Approve</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Boarding Code</th>
                                <th>Status</th>
                                <th>Subscription</th>
                                <th style="width: 250px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($non_pending_owners) > 0): ?>
                                <?php foreach ($non_pending_owners as $owner): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($owner['name']); ?></td>
                                        <td><?php echo htmlspecialchars($owner['email']); ?></td>
                                        <td><span class="badge bg-secondary"><?php echo htmlspecialchars($owner['boarding_code']); ?></span></td>
                                        <td>
                                            <?php
                                                $status_badge = 'secondary';
                                                if ($owner['account_status'] == 'active') $status_badge = 'success';
                                                if ($owner['account_status'] == 'payment_due') $status_badge = 'warning';
                                                if ($owner['account_status'] == 'restricted') $status_badge = 'danger';
                                                if ($owner['account_status'] == 'pending') $status_badge = 'info';
                                            ?>
                                            <span class="badge bg-<?php echo $status_badge; ?>"><?php echo ucfirst(str_replace('_', ' ', $owner['account_status'])); ?></span>
                                        </td>
                                        <td>
                                            <?php 
                                            if ($owner['account_status'] == 'active' && !empty($owner['end_date'])) {
                                                $days_left = ceil((strtotime($owner['end_date']) - time()) / 86400);
                                                if ($days_left > 0) {
                                                    echo '<span class="text-success fw-bold">' . $days_left . ' days left</span>';
                                                } else {
                                                    echo '<span class="text-danger">Expired</span>';
                                                }
                                                echo '<br><small class="text-muted">Ends: ' . date('M d, Y', strtotime($owner['end_date'])) . '</small>';
                                            } else {
                                                echo '<span class="text-muted">-</span>';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <form action="update_owner_status.php" method="POST" class="d-flex gap-2">
                                                <input type="hidden" name="admin_id" value="<?php echo $owner['id']; ?>">
                                                <select name="account_status" class="form-select form-select-sm">
                                                    <option value="active" <?php if ($owner['account_status'] == 'active') echo 'selected'; ?>>Active</option>
                                                    <option value="payment_due" <?php if ($owner['account_status'] == 'payment_due') echo 'selected'; ?>>Payment Due</option>
                                                    <option value="restricted" <?php if ($owner['account_status'] == 'restricted') echo 'selected'; ?>>Restricted</option>
                                                </select>
                                                <button type="submit" class="btn btn-sm btn-primary">Save</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center">No owners found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>