<?php
// This header file now handles session starting, config inclusion,
// and all account status enforcement (suspended/payment_due checks).
require_once 'header.php';

$admin_id = $_SESSION['admin_id'];
$boarding_code = $_SESSION['boarding_code'];
$message = "";

// ✅ Handle add notice
if (isset($_POST["add_notice"]) && !in_array($account_status, ['pending', 'restricted'])) {
    $title = trim($_POST['title']);
    $body = trim($_POST['body']);

    if (!empty($title) && !empty($body)) {
        $stmt = $conn->prepare("INSERT INTO notices (title, body, boarding_code, admin_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $title, $body, $boarding_code, $admin_id);
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Announcement added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>Please fill in all fields.</div>";
    }
}

// ✅ Handle delete notice
if (isset($_POST["delete_notice"]) && !in_array($account_status, ['pending', 'restricted'])) {
    $id = intval($_POST["id"]);
    $stmt = $conn->prepare("DELETE FROM notices WHERE id = ? AND admin_id = ?");
    $stmt->bind_param("ii", $id, $admin_id);
    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>Announcement deleted successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error deleting announcement.</div>";
    }
}

// ✅ Handle update notice
if (isset($_POST["update_notice"]) && !in_array($account_status, ['pending', 'restricted'])) {
    $id = intval($_POST["id"]);
    $title = trim($_POST['title']);
    $body = trim($_POST['body']);
    if (!empty($title) && !empty($body)) {
        $stmt = $conn->prepare("UPDATE notices SET title = ?, body = ? WHERE id = ? AND admin_id = ?");
        $stmt->bind_param("ssii", $title, $body, $id, $admin_id);
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Announcement updated successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error updating announcement.</div>";
        }
    }
}

// ✅ Fetch all notices
$stmt = $conn->prepare("SELECT * FROM notices WHERE boarding_code = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $boarding_code);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Announcements</title>
    <link rel="stylesheet" href="side.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <?php include("navbar.php"); ?>
  <div class="main">
    <div class="container-fluid">
        <h3 class="fw-bold text-dark">📢 Manage Announcements</h3>

        <?= $message ?>

        <!-- Add Notice Form -->
        <?php if (!in_array($account_status, ['pending', 'restricted'])): ?>
        <div class="card shadow-sm border-0 p-4 mb-4">
            <h2>Add New Announcement</h2>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Body</label>
                    <textarea name="body" rows="4" class="form-control" required></textarea>
                </div>
                <button type="submit" name="add_notice" class="btn btn-primary">Post Announcement</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Notices List -->
        <div class="row g-3">
            <h4 class="mt-4">All Announcements</h4>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col-md-6">
                        <div class="card shadow-sm border-0 h-100">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
                                <p class="card-text text-muted" style="font-size: 0.9rem;"><?= nl2br(htmlspecialchars($row['body'])) ?></p>
                            </div>
                            <div class="card-footer bg-white border-0">
                                <small class="text-muted">Posted on <?= date("M d, Y", strtotime($row['created_at'])) ?></small>
                                <div class="float-end">
                                    <?php if (!in_array($account_status, ['pending', 'restricted'])): ?>
                                    <button class="btn btn-warning btn-sm" title="Edit"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editModal" 
                                            data-id="<?= $row['id'] ?>" 
                                            data-title="<?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?>" 
                                            data-body='<?= json_encode($row['body']) ?>'>
                                        <i class="fa fa-edit"></i> 
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button type="submit" name="delete_notice" title="Delete" class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i> 
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-muted">No announcements yet.</p>
            <?php endif; ?>
        </div>
    </div>
  </div>

  <!-- Edit Modal -->
  <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST">
            <div class="modal-header">
                <h5 class="modal-title">Edit Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" id="edit-title" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Body</label>
                    <textarea name="body" id="edit-body" rows="4" class="form-control" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="update_notice" class="btn btn-success">Save Changes</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    
    var editModal = document.getElementById('editModal');
    editModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var id = button.getAttribute('data-id');
      var title = button.getAttribute('data-title');
      var body = JSON.parse(button.getAttribute('data-body')); // Safely parse the JSON string

      document.getElementById('edit-id').value = id;
      document.getElementById('edit-title').value = title;
      document.getElementById('edit-body').value = body;
    });
  </script>
</body>
</html>
