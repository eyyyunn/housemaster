<?php
session_start();
include __DIR__ . "/../config.php";

// Ensure admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin-login.php");
    exit();
}

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_method = $_POST['payment_method'] ?? '';

    if (empty($payment_method)) {
        $message = "Please select a payment method before submitting.";
        $message_type = "danger";
    } elseif (isset($_FILES["payment_proof"]) && $_FILES["payment_proof"]["error"] == 0) {
        $target_dir = "../assets/uploads/payment_proofs/";
        // to Create the directory if it doesn't exist
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_extension = strtolower(pathinfo($_FILES["payment_proof"]["name"], PATHINFO_EXTENSION));
        $allowed_types = ["jpg", "jpeg", "png"];

        if (in_array($file_extension, $allowed_types)) {
            // Generate a unique filename
            $new_filename = "proof_" . $_SESSION['admin_id'] . "_" . time() . "." . $file_extension;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $target_file)) {
                // Update admin record with payment proof and method
                $stmt = $conn->prepare("UPDATE admins SET payment_proof = ?, payment_method = ?, account_status = 'pending' WHERE id = ?");
                $stmt->bind_param("ssi", $new_filename, $payment_method, $_SESSION['admin_id']);
                
                if ($stmt->execute()) {
                    
                    header("Location: dashboard.php");
                    exit();
                } else { 
                    $message = "Database error. Please ensure the `payment_proof` and `payment_method` columns exist in your `admins` table.";
                    $message_type = "danger";
                }
            } else {
                $message = "Sorry, there was an error uploading your file.";
                $message_type = "danger";
            }
        } else {
            $message = "Only JPG, JPEG, and PNG files are allowed.";
            $message_type = "danger";
        }
    } else {
        $message = "Please select a file to upload.";
        $message_type = "danger";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Payment Verification</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f5f7fa; font-family: 'Segoe UI', sans-serif; height: 100vh; display: flex; justify-content: center; align-items: center; }
    .payment-box { width: 450px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); padding: 30px; }
    .payment-box h3 { text-align: center; margin-bottom: 20px; color: #05445E; font-weight: bold; }
    .btn-primary { background: #05445E; border: none; }
    .btn-primary:hover { background: #032f40; }
  </style>
</head>
<body>
  <div class="payment-box">
    <h3>Payment Verification</h3>
    
    <?php if (!empty($message)) : ?>
      <div class="alert alert-<?php echo $message_type; ?> py-2"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label fw-bold">Select Payment Method</label>
        <select id="paymentMethod" class="form-select" onchange="togglePaymentDetails()">
            <option value="" selected disabled>Choose an option...</option>
            <option value="gcash">GCash</option>
            <option value="bank">Bank Transfer</option>
        </select>
    </div>

    <div id="gcashDetails" class="mb-4 p-3 bg-light rounded border d-none">
        <h5 class="h6 fw-bold text-primary">GCash Payment</h5>
        <p class="small mb-2">Please send your subscription payment to:</p>
        <ul class="list-unstyled small mb-0">
            <li><strong>Number:</strong> 0912 345 6789</li>
            <li><strong>Name:</strong> HouseMaster</li>
        </ul>
    </div>

    <div id="bankDetails" class="mb-4 p-3 bg-light rounded border d-none">
        <h5 class="h6 fw-bold text-primary">Bank Transfer</h5>
        <p class="small mb-2">Please deposit your payment to:</p>
        <ul class="list-unstyled small mb-0">
            <li><strong>Bank:</strong> BDO</li>
            <li><strong>Account No:</strong> 1234 5678 9012</li>
            <li><strong>Account Name:</strong> HouseMaster Inc.</li>
        </ul>
    </div>

    <div id="uploadSection" class="d-none">
        <p class="text-muted text-center mb-3">Upload a screenshot of your successful payment to proceed to the dashboard.</p>
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="payment_method" id="paymentMethodInput">
          <div class="mb-3"><label class="form-label">Payment Screenshot</label><input type="file" name="payment_proof" class="form-control" accept="image/*" required></div>
          <button type="submit" class="btn btn-primary w-100">Submit & Proceed</button>
        </form>
    </div>
    <div class="text-center mt-2"><a href="dashboard.php" class="text-decoration-none small">Back to Dashboard</a></div>
    <div class="text-center mt-3"><a href="admin-logout.php" class="text-decoration-none text-secondary small">Logout</a></div>
  </div>
  <script>
    function togglePaymentDetails() {
        const method = document.getElementById('paymentMethod').value;
        const gcash = document.getElementById('gcashDetails');
        const bank = document.getElementById('bankDetails');
        const upload = document.getElementById('uploadSection');
        const paymentMethodInput = document.getElementById('paymentMethodInput');

        gcash.classList.add('d-none');
        bank.classList.add('d-none');
        upload.classList.add('d-none');

        if (method === 'gcash') {
            gcash.classList.remove('d-none');
            upload.classList.remove('d-none');
            paymentMethodInput.value = 'gcash';
        } else if (method === 'bank') {
            bank.classList.remove('d-none');
            upload.classList.remove('d-none');
            paymentMethodInput.value = 'bank';
        }
    }
  </script>
</body>
</html>