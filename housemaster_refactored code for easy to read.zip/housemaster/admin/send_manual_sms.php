<?php
session_start();
include __DIR__ . "/../config.php";

// Require admin login
if (!isset($_SESSION["admin_id"])) {
    header("Location: admin-login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$tenant_id = isset($_GET['tenant_id']) ? (int)$_GET['tenant_id'] : 0;
$days_remaining = isset($_GET['days_remaining']) ? (int)$_GET['days_remaining'] : null;

if ($tenant_id === 0) {
    die("No tenant specified.");
}

// =================================================
// TextBee SMS Gateway Configuration
// =================================================
// 1. Make sure your phone's IP address is correct. If using a mobile hotspot, it's usually 192.168.43.1
define('TEXTBEE_GATEWAY_URL', 'http://192.168.43.1:8080/api/send_sms');

// 2. VERY IMPORTANT: Replace 'YOUR_TEXTBEE_API_KEY' with the actual key from your TextBee app's settings.
define('TEXTBEE_API_KEY', 'YOUR_TEXTBEE_API_KEY'); 

// =================================================
// 1. Find the tenant's next due payment
// =================================================

$stmt = $conn->prepare("
    SELECT t.fullname, t.phone, p.amount, p.due_date
    FROM payments p
    JOIN tenants t ON p.tenant_id = t.id
    WHERE p.tenant_id = ? AND t.admin_id = ? AND p.status = 'pending'
    ORDER BY p.due_date ASC
    LIMIT 1
");
$stmt->bind_param("ii", $tenant_id, $admin_id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if (!$payment) {
    die("No pending payment found for this tenant.");
}

// =================================================
// 2. Send the SMS via the gateway
// =================================================

$tenant_phone = $payment['phone'];
$due_date_formatted = date("M d, Y", strtotime($payment['due_date']));
$amount_formatted = number_format($payment['amount']);
$message_body = "";

if ($days_remaining !== null) {
    if ($days_remaining < 0) {
        $message_body = "Hi " . $payment['fullname'] . ", your payment of ₱" . $amount_formatted . " is overdue by " . abs($days_remaining) . " day(s). Please settle it as soon as possible. - HouseMaster";
    } elseif ($days_remaining == 0) {
        $message_body = "Hi " . $payment['fullname'] . ", a friendly reminder that your payment of ₱" . $amount_formatted . " is due today, " . $due_date_formatted . ". - HouseMaster";
    } else {
        $message_body = "Hi " . $payment['fullname'] . ", a friendly reminder that your payment of ₱" . $amount_formatted . " is due in " . $days_remaining . " day(s) on " . $due_date_formatted . ". - HouseMaster";
    }
} else {
    // Fallback message if days_remaining is not passed for some reason
    $message_body = "Hi " . $payment['fullname'] . ", a friendly reminder that your payment of ₱" . $amount_formatted . " is due on " . $due_date_formatted . ". - HouseMaster";
}

// Prepare the data for the POST request
$postData = [
    'phone_number' => $tenant_phone,
    'sms_content'  => $message_body,
    'api_key'      => TEXTBEE_API_KEY
];

// Use cURL to send the HTTP request to the Android gateway
$ch = curl_init(TEXTBEE_GATEWAY_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 3. Redirect back with a message
$status_filter = !empty($_GET['status']) ? "?status=".$_GET['status'] : "";

if ($http_code == 200) {
    // You can optionally set a session flash message here to show a success alert
    // $_SESSION['message'] = "SMS reminder sent successfully to " . $payment['fullname'];
} else {
    // $_SESSION['message'] = "ERROR: Failed to send SMS. Gateway response code: " . $http_code;
}

header("Location: tenants.php" . $status_filter);
exit();