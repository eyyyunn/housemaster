<?php
// This header file now handles session starting, config inclusion,
// and all account status enforcement (suspended/payment_due checks).
require_once 'header.php';

$admin_id = $_SESSION['admin_id'];
$message = "";

// Display session-based messages
if (isset($_SESSION['message'])) { // This block is hit on redirect after an action
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
    // Set a timestamp to notify other open tabs that a change has occurred.
    $_SESSION['last_update_timestamp'] = time();
}

// ✅ Fetch payment status counts for the summary info
$counts_stmt = $conn->prepare("
    SELECT 
        p.status, 
        COUNT(p.id) as count
    FROM payments p
    JOIN tenants t ON p.tenant_id = t.id
    WHERE t.admin_id = ?
    GROUP BY p.status
");
$counts_stmt->bind_param("i", $admin_id);
$counts_stmt->execute();
$counts_result = $counts_stmt->get_result();

$payment_counts = ['paid' => 0, 'pending' => 0, 'total' => 0];
while ($row_count = $counts_result->fetch_assoc()) {
    if (isset($payment_counts[$row_count['status']])) {
        $payment_counts[$row_count['status']] = $row_count['count'];
    }
    $payment_counts['total'] += $row_count['count'];
}

// Get specific count for overdue payments
$overdue_stmt = $conn->prepare("SELECT COUNT(p.id) as count FROM payments p JOIN tenants t ON p.tenant_id = t.id WHERE t.admin_id = ? AND p.status = 'pending' AND p.due_date < CURDATE()");
$overdue_stmt->bind_param("i", $admin_id);
$overdue_stmt->execute();
$payment_counts['overdue'] = $overdue_stmt->get_result()->fetch_assoc()['count'];


// Handle "Mark as Paid" action
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['mark_as_paid']) && !in_array($account_status, ['pending', 'restricted'])) {
    $payment_id = $_POST['payment_id'];

    // Security check: ensure the admin can only update payments for their own tenants
    $stmt = $conn->prepare("
        UPDATE payments p
        JOIN tenants t ON p.tenant_id = t.id
        SET p.status = 'paid'
        WHERE p.id = ? AND t.admin_id = ?
    ");
    $stmt->bind_param("ii", $payment_id, $admin_id);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        // Success - Rebuild the query string to preserve filters
        unset($_POST['mark_as_paid']); // Remove the POST variable
        $query_string = http_build_query($_GET); // Use existing GET params
        header("Location: payments.php" . ($query_string ? "?".$query_string : ""));
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Error updating payment status or payment not found.</div>";
    }
}

// Handle status filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : "";
$month_filter = isset($_GET['month']) ? $_GET['month'] : "";
$tenant_filter = isset($_GET['tenant_id']) ? (int)$_GET['tenant_id'] : 0;

$is_overdue_filter = ($status_filter === 'overdue');
if ($is_overdue_filter) {
    $status_filter = 'pending'; // Overdue is a subset of pending
}

// Build query to fetch payments
$sql = "
    SELECT p.id, p.amount, p.due_date, p.status, t.id AS tenant_id, t.fullname AS tenant_name, t.email AS tenant_email
    FROM payments p
    JOIN tenants t ON p.tenant_id = t.id
    WHERE t.admin_id = ?
";

$params = [$admin_id];
$types = "i";

if (!empty($status_filter)) {
    $sql .= " AND p.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($month_filter) && is_numeric($month_filter)) {
    $sql .= " AND MONTH(p.due_date) = ?";
    $params[] = $month_filter;
    $types .= "i";
}

if ($tenant_filter > 0) {
    $sql .= " AND p.tenant_id = ?";
    $params[] = $tenant_filter;
    $types .= "i";
}

if ($is_overdue_filter) {
    $sql .= " AND p.due_date < CURDATE()";
}

$sql .= " ORDER BY p.due_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Get tenant name for the header if filtering by tenant
$tenant_name_for_header = "";
if ($tenant_filter > 0) {
    $tenant_stmt = $conn->prepare("SELECT fullname FROM tenants WHERE id = ? AND admin_id = ?");
    $tenant_stmt->bind_param("ii", $tenant_filter, $admin_id);
    $tenant_stmt->execute();
    $tenant_name_for_header = $tenant_stmt->get_result()->fetch_assoc()['fullname'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Payments</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
</head>
<body>
  <!-- Sidebar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main p-4">
    <h3 class="fw-bold text-dark">💰 Payments
        <?php if ($tenant_name_for_header): ?>
            <small class="text-muted fs-5">- <?php echo htmlspecialchars($tenant_name_for_header); ?></small>
        <?php endif; ?>
    </h3>

    <?php if (!empty($message)): ?>
        <?php echo $message; ?>
    <?php endif; ?>

    <!-- Status Summary Info -->
    <div class="d-flex flex-wrap align-items-center gap-3 mb-4">
        <span class="fw-bold">Total Payments: <span class="badge bg-primary rounded-pill"><?php echo $payment_counts['total']; ?></span></span>
        <span class="ms-3">Paid: <span class="badge bg-success rounded-pill"><?php echo $payment_counts['paid']; ?></span></span>
        <span>Pending: <span class="badge bg-warning rounded-pill"><?php echo $payment_counts['pending']; ?></span></span>
        <span>Overdue: <span class="badge bg-danger rounded-pill"><?php echo $payment_counts['overdue']; ?></span></span>
    </div>

    <!-- Filter -->
    <form method="GET" class="mb-3">
      <div class="row g-2 align-items-center">
        <div class="col-md-3">
          <select name="status" class="form-select">
            <option value="">-- Filter by Status --</option>
            <option value="pending" <?php if ($status_filter == "pending" && !$is_overdue_filter) echo "selected"; ?>>Pending</option>
            <option value="overdue" <?php if ($is_overdue_filter) echo "selected"; ?>>Overdue</option>
            <option value="paid" <?php if ($status_filter == "paid") echo "selected"; ?>>Paid</option>
          </select>
        </div>
        <div class="col-md-3">
          <select name="month" class="form-select">
            <option value="">-- Filter by Month --</option>
            <?php
            $months = [
                '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
                '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
                '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
            ];
            foreach ($months as $num => $name) {
                $selected = ($month_filter == $num) ? 'selected' : '';
                echo "<option value='{$num}' {$selected}>{$name}</option>";
            }
            ?>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Apply</button>
        </div>
        <div class="col-md-2">
          <a href="payments.php" class="btn btn-secondary w-100">Reset</a>
        </div>
      </div>
    </form>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>Tenant</th>
              <th>Amount</th>
              <th>Due Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo htmlspecialchars($row['tenant_name']); ?></td>
                  <td>₱<?php echo number_format($row['amount'], 2); ?></td>
                  <td><?php echo date("M d, Y", strtotime($row['due_date'])); ?></td>
                  <td> 
                    <?php
                        $payment_status = $row['status'];
                        $display_status = ucfirst($payment_status);
                        $badge_class = 'warning';

                        if ($payment_status == 'paid') {
                            $badge_class = 'success';
                        } elseif ($payment_status == 'pending' && strtotime($row['due_date']) < time()) {
                            $display_status = 'Overdue';
                            $badge_class = 'danger';
                        }
                    ?>
                    <span class="badge bg-<?php echo $badge_class; ?>">
                      <?php echo $display_status; ?>
                    </span>
                  </td>
                  <td>
                    <?php if ($row['status'] == 'pending' && !in_array($account_status, ['pending', 'restricted'])): ?>
                        <div class="btn-group">
                            <form method="POST" class="d-inline" onsubmit="return confirm('Mark this payment as paid?')">
                                <input type="hidden" name="payment_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="mark_as_paid" class="btn btn-sm btn-success" title="Mark as Paid">
                                <i class="fas fa-check"></i>
                                </button>
                            </form>

                            <div class="btn-group ms-1" title="Send Reminder">
                                <button type="button" class="btn btn-sm btn-info dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-bell"></i> Notify
                                </button>
                                <ul class="dropdown-menu">
                                    <?php
                                        $today = new DateTime();
                                        $dueDate = new DateTime($row['due_date']);
                                        $days_remaining = (int)$today->diff($dueDate)->format('%r%a');
                                        $amount_formatted = number_format($row['amount']);
                                        $due_date_formatted = date("M d, Y", strtotime($row['due_date']));
                                        $message_template = "Hi " . htmlspecialchars($row['tenant_name']) . ", this is a reminder for your payment of ₱" . $amount_formatted . " due on " . $due_date_formatted . ". Thank you. - HouseMaster";
                                    ?>
                                    <li><a class="dropdown-item" href="send_manual_sms.php?<?php echo http_build_query(array_merge($_GET, ['tenant_id' => $row['tenant_id'], 'days_remaining' => $days_remaining])); ?>" onclick="return confirm('Send an SMS payment reminder to this tenant?')"><i class="fas fa-comment-sms fa-fw me-2"></i>Via SMS</a></li>
                                    <li><a class="dropdown-item" href="send_email_reminder.php?<?php echo http_build_query(array_merge($_GET, ['tenant_id' => $row['tenant_id']])); ?>" onclick="return confirm('Send an email payment reminder to this tenant?')"><i class="fas fa-envelope fa-fw me-2"></i>Via Email</a></li>
                                    <li>
                                        <form action="send_platform_message.php" method="POST" onsubmit="return confirm('Send this platform message reminder?');" style="display: inline;">
                                            <input type="hidden" name="tenant_id" value="<?php echo $row['tenant_id']; ?>">
                                            <input type="hidden" name="message" value="<?php echo htmlspecialchars($message_template); ?>">
                                            <input type="hidden" name="redirect_url" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                                            <button type="submit" class="dropdown-item">
                                                <i class="fas fa-paper-plane fa-fw me-2"></i>Via Platform
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    <?php else: ?>
                      <span class="text-muted">N/A</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="text-center text-muted">No payments found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
 
  <script>
    
    window.housemaster_last_update = <?php echo isset($_SESSION['last_update_timestamp']) ? $_SESSION['last_update_timestamp'] : 0; ?>;
  </script>
  <script src="assets/js/autoupdate.js"></script>
</body>
</html>
