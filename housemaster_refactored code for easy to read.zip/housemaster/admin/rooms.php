<?php
// This header file now handles session starting, config inclusion,
// and all account status enforcement (suspended/payment_due checks).
require_once 'header.php';

// Get the boarding code for the logged-in admin
$boarding_code = $_SESSION['boarding_code'];

$message = "";

// Add Room
if (isset($_POST['add_room']) && !in_array($account_status, ['pending', 'restricted'])) {
    $room_label = $_POST['room_label'];
    $capacity    = $_POST['capacity'];
    $rental_rate = $_POST['rental_rate'];
    // Generate a unique code for the room
    $room_code = strtoupper(substr(md5(uniqid($room_label, true)), 0, 8));

    $stmt = $conn->prepare("INSERT INTO rooms (room_label, capacity, rental_rate, boarding_code, room_code) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sidss", $room_label, $capacity, $rental_rate, $boarding_code, $room_code);
    if ($stmt->execute()) {
        header("Location: rooms.php");
        exit();
    } else {
        $message = "Error: " . $conn->error;
    }
}

// Handle Update Room
if (isset($_POST['update_room']) && !in_array($account_status, ['pending', 'restricted'])) {
    $room_id_to_update = $_POST['room_id'];
    $capacity = $_POST['capacity'];
    $rental_rate = $_POST['rental_rate'];

    // Security check: ensure admin can only edit their own rooms
    $update_stmt = $conn->prepare("UPDATE rooms SET capacity = ?, rental_rate = ? WHERE id = ? AND boarding_code = ?");
    $update_stmt->bind_param("idis", $capacity, $rental_rate, $room_id_to_update, $boarding_code);
    
    if ($update_stmt->execute()) {
        header("Location: rooms.php");
        exit();
    } else {
        $message = "Error updating room: " . $conn->error;
    }
}

// Fetch tenants & rooms
$all_rooms_stmt = $conn->prepare("
    SELECT r.*, 
           (SELECT COUNT(tr.id) FROM tenant_rooms tr JOIN tenants t ON tr.tenant_id = t.id WHERE tr.room_id = r.id AND t.status = 'active') AS tenants
    FROM rooms r
    WHERE r.boarding_code = ? 
    GROUP BY r.id 
    ORDER BY r.created_at DESC");
$all_rooms_stmt->bind_param("s", $boarding_code);
$all_rooms_stmt->execute();
$all_rooms = $all_rooms_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Room Management — HouseMaster</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="side.css">

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="main.css">
<style>

    .bg-primary {
    --bs-bg-opacity: 1;
    background-color: #212529 !important;
    }

    .btn-success {
    --bs-btn-color: #fff;
    --bs-btn-bg: #0d6efd;
    --bs-btn-border-color: #0d6efd;
    --bs-btn-hover-color: #fff;
    --bs-btn-hover-bg: #0d6efd;
    --bs-btn-hover-border-color: #0d6efd;
    --bs-btn-focus-shadow-rgb: 60, 153, 110;
    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: #0d6efd;
    --bs-btn-active-border-color: #0d6efd;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #fff;
    --bs-btn-disabled-bg: #0d6efd;
    --bs-btn-disabled-border-color: #0d6efd;

}

</style>
</head>
<body>
<?php include("navbar.php"); ?>
<div class="main p-4">
    <h3 class="fw-bold text-dark mb-3">🏠 Room Management</h3>
    <?php if (!empty($message)): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>
    

    <div class="add-con">
    <?php if (!in_array($account_status, ['pending', 'restricted'])): ?>
    <!-- Add Room -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-primary text-white">Add Room</div>
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label>Room Label</label>
                            <input type="text" name="room_label" class="form-control" placeholder="e.g. Dorm A - Room 1" required>
                        </div>
                        <div class="col-md-4">
                            <label>Capacity</label>
                            <input type="number" name="capacity" class="form-control" min="1" required>
                        </div>
                        <div class="col-md-4">
                            <label>Rental Rate (₱)</label>
                            <input type="number" step="0.01" name="rental_rate" class="form-control" required>
                        </div>
                    </div>
                    <button type="submit" name="add_room" class="btn btn-success mt-3">Add Room</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
    </div>

    <div class="rooms-con">
    <!-- All Rooms -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white">All Rooms</div>
            <div class="card-body pb-0">
                <div class="row">
                    <div class="col-md-4">
                        <label for="sortControl" class="form-label">Sort by:</label>
                        <select id="sortControl" class="form-select form-select-sm">
                            <option value="0-asc">Default</option>
                            <option value="1-asc">Room Label (A-Z)</option>
                            <option value="1-desc">Room Label (Z-A)</option>
                            <option value="2-desc">Occupancy (High to Low)</option>
                            <option value="2-asc">Occupancy (Low to High)</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="card-body table-responsive">
                <table id="roomsTable" class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Room Label</th>
                            <th>Occupancy</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1; while ($row = $all_rooms->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $i++; ?></td>
                                <td><?php echo htmlspecialchars($row['room_label']); ?></td>
                                <?php
                                    $tenants = (int)$row['tenants'];
                                    $capacity = (int)$row['capacity'];
                                    $occupancy_percentage = ($capacity > 0) ? ($tenants / $capacity) * 100 : 0;
                                    $progress_color = 'bg-success'; // Green for available
                                    if ($occupancy_percentage >= 90) {
                                        $progress_color = 'bg-danger'; // Red for near/full
                                    } elseif ($occupancy_percentage >= 50) {
                                        $progress_color = 'bg-warning'; // Yellow for half-full
                                    }
                                ?>
                                <td data-sort="<?php echo $occupancy_percentage; ?>">
                                    <div class="d-flex align-items-center">
                                        <span class="me-2"><?php echo $tenants; ?> / <?php echo $capacity; ?></span>
                                        <div class="progress flex-grow-1" style="height: 10px;">
                                            <div class="progress-bar <?php echo $progress_color; ?>" role="progressbar" style="width: <?php echo $occupancy_percentage; ?>%;" aria-valuenow="<?php echo $occupancy_percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary" title="View Details" data-bs-toggle="modal" data-bs-target="#roomDetailsModal<?php echo $row['id']; ?>"><i class="fas fa-eye"></i></button>
                                        <?php if (!in_array($account_status, ['pending', 'restricted'])): ?>
                                        <button class="btn btn-sm btn-outline-warning" title="Edit Room" data-bs-toggle="modal" data-bs-target="#editRoomModal<?php echo $row['id']; ?>"><i class="fas fa-edit"></i></button>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" title="Manage Room"><i class="fas fa-cog"></i></button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="#" onclick="openModal(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars(addslashes($row['room_label'])); ?>', 'item')"><i class="fas fa-plus-circle fa-fw me-2"></i>Manage Items</a></li>
                                                <li><a class="dropdown-item" href="#" onclick="openModal(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars(addslashes($row['room_label'])); ?>', 'rule')"><i class="fas fa-gavel fa-fw me-2"></i>Manage Rules</a></li>
                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                            <!-- Room Details Modal -->
                            <div class="modal fade" id="roomDetailsModal<?php echo $row['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Room Details: <?php echo htmlspecialchars($row['room_label']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            
                                            <p><strong>Capacity:</strong> <?php echo $row['capacity']; ?> tenant(s)</p>
                                            <p><strong>Rental Rate:</strong> ₱<?php echo number_format($row['rental_rate'], 2); ?></p>
                                            <hr>
                                            <h6>Assigned Tenants</h6>
                                            <?php
                                            $tenant_list_stmt = $conn->prepare("SELECT t.id, t.fullname FROM tenants t JOIN tenant_rooms tr ON t.id = tr.tenant_id WHERE tr.room_id = ?");
                                            $tenant_list_stmt->bind_param("i", $row['id']);
                                            $tenant_list_stmt->execute();
                                            $tenant_list = $tenant_list_stmt->get_result();
                                            if ($tenant_list->num_rows > 0) {
                                                echo '<ul class="list-group">';
                                                while ($t = $tenant_list->fetch_assoc()) {
                                                    echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
                                                    echo htmlspecialchars($t['fullname']);
                                                    echo '<div>';
                                                    echo '<form method="POST" class="d-inline">';
                                                    echo '<input type="hidden" name="tenant_id" value="' . $t['id'] . '">';
                                                    echo '<!-- Actions moved to Tenants Profile page -->';
                                                    echo '</form>';
                                                    echo '</div>';
                                                    echo '</li>';
                                                }
                                                echo '</ul>';
                                            } else {
                                                echo '<p class="text-muted">No tenants assigned to this room.</p>';
                                            }
                                            ?>

                                            <hr>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6><i class="fas fa-check-circle me-2"></i>Room Inclusions</h6>
                                                    <?php
                                                    $items_stmt = $conn->prepare("SELECT item_name, quantity, `condition` FROM room_items WHERE room_id = ? ORDER BY created_at ASC");
                                                    $items_stmt->bind_param("i", $row['id']);
                                                    $items_stmt->execute();
                                                    $items_list = $items_stmt->get_result();
                                                    if ($items_list->num_rows > 0) {
                                                        echo '<ul class="list-group list-group-flush">';
                                                        while ($item = $items_list->fetch_assoc()) {
                                                            echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
                                                            echo htmlspecialchars($item['item_name']);
                                                            echo '<div><span class="badge bg-secondary">x' . htmlspecialchars($item['quantity']) . '</span> <span class="badge bg-info text-dark">' . htmlspecialchars($item['condition']) . '</span></div>';
                                                            echo '</li>';
                                                        }
                                                        echo '</ul>';
                                                    } else {
                                                        echo '<p class="text-muted">No items specified.</p>';
                                                    }
                                                    ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6><i class="fas fa-gavel me-2"></i>House Rules</h6>
                                                    <?php
                                                    $rules_stmt = $conn->prepare("SELECT rule_text FROM room_rules WHERE room_id = ? AND type = 'rule' ORDER BY created_at ASC");
                                                    $rules_stmt->bind_param("i", $row['id']);
                                                    $rules_stmt->execute();
                                                    $rules_list = $rules_stmt->get_result();
                                                    if ($rules_list->num_rows > 0) {
                                                        echo '<ul class="list-group list-group-flush">';
                                                        while ($rule = $rules_list->fetch_assoc()) {
                                                            echo '<li class="list-group-item">' . htmlspecialchars(trim($rule['rule_text'])) . '</li>';
                                                        }
                                                        echo '</ul>';
                                                    } else {
                                                        echo '<p class="text-muted">No rules specified.</p>';
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Edit Room Modal -->
                            <div class="modal fade" id="editRoomModal<?php echo $row['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Room: <?php echo htmlspecialchars($row['room_label']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="room_id" value="<?php echo $row['id']; ?>">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label>Capacity</label>
                                                        <input type="number" name="capacity" class="form-control" min="1" value="<?php echo $row['capacity']; ?>" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label>Rental Rate (₱)</label>
                                                        <input type="number" step="0.01" name="rental_rate" class="form-control" value="<?php echo $row['rental_rate']; ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <div>
                                                </div>
                                                <div>
                                                    <button type="submit" name="update_room" class="btn btn-success">Save Changes</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="rulesModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="rulesModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="rulesContent"></div>
    </div>
  </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables JS -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    var table = $('#roomsTable').DataTable({
        "ordering": true, // Keep ordering enabled for the API
        "columnDefs": [
            { "orderable": false, "targets": "_all" } // But disable header-click sorting UI
        ]
    });

    $('#sortControl').on('change', function() {
        var val = $(this).val();
        var parts = val.split('-');
        var colIndex = parseInt(parts[0], 10);
        table.order([colIndex, parts[1]]).draw();
    });
});
// Open Room Rules Modal
function openModal(roomId, roomLabel, type) {
    const typeTitle = type.charAt(0).toUpperCase() + type.slice(1); // Capitalize
    document.getElementById("rulesModalLabel").textContent = `Manage ${typeTitle}s for ${roomLabel}`;
    loadModalContent(roomId, type);
}

function loadModalContent(roomId, type) {
    fetch(`room_rules.php?room_id=${roomId}&type=${type}`)
        .then(res => res.text())
        .then(html => {
            const modalBody = document.getElementById("rulesContent");
            modalBody.innerHTML = html;
            attachModalHandlers(roomId, type);

            let rulesModal = bootstrap.Modal.getOrCreateInstance(document.getElementById("rulesModal"));
            rulesModal.show();
        })
        .catch(err => console.error(err));
}

// Attach event listeners after modal content loads
function attachModalHandlers(roomId, type) {
    const modalBody = document.getElementById("rulesContent");

    // Add rule
    const addForm = modalBody.querySelector('form'); // Generalize to find any form
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('add_item_or_rule', '1');
            fetch(`room_rules.php?room_id=${roomId}&type=${type}`, {
                method: "POST",
                body: formData
            })
            .then(res => res.text())
            .then(html => {
                modalBody.innerHTML = html;
                attachModalHandlers(roomId, type); // Reattach listeners
            })
            .catch(err => console.error(err));
        });
    }

    // Delete rule
    modalBody.querySelectorAll('.delete-item-or-rule').forEach(btn => {
        btn.addEventListener('click', function() {
            if (!confirm(`Are you sure you want to delete this ${type}?`)) return;
            const formData = new FormData();
            formData.append('delete_item_or_rule', '1');
            formData.append('item_id', this.dataset.id);
            fetch(`room_rules.php?room_id=${roomId}&type=${type}`, {
                method: "POST",
                body: formData
            })
            .then(res => res.text())
            .then(html => {
                modalBody.innerHTML = html;
                attachModalHandlers(roomId, type); // Reattach listeners
            })
            .catch(err => console.error(err));
        });
    });
}


</script>
</body>
</html>
