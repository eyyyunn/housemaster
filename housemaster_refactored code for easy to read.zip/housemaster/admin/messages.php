<?php
// This header file now handles session starting, config inclusion,
// and all account status enforcement (suspended/payment_due checks).
require_once 'header.php';

$admin_id = $_SESSION["admin_id"];
$boarding_code = $_SESSION['boarding_code'];

// Get the selected tenant to chat with
$tenant_id = isset($_GET['tenant_id']) ? (int)$_GET['tenant_id'] : 0; // 0 for none, -1 for System
$prefilled_message = isset($_GET['message']) ? trim($_GET['message']) : '';

// Fetch tenants who have sent messages to this admin
$tenants_stmt = $conn->prepare(
    "SELECT DISTINCT t.id, t.fullname, r.room_label
     FROM tenants t 
     LEFT JOIN tenant_rooms tr ON t.id = tr.tenant_id
     LEFT JOIN rooms r ON tr.room_id = r.id
     JOIN messages m ON (m.sender_id = t.id AND m.sender_type = 'tenant' AND m.receiver_id = ?) OR (m.receiver_id = t.id AND m.sender_type = 'admin' AND m.sender_id = ?)
     WHERE t.admin_id = ?"
);
$tenants_stmt->bind_param("iii", $admin_id, $admin_id, $admin_id);
$tenants_stmt->execute();
$tenants = $tenants_stmt->get_result();
$tenant_list = $tenants->fetch_all(MYSQLI_ASSOC); // Fetch all to array to prepend System

// Check for System messages
$sys_check = $conn->prepare("SELECT COUNT(id) as count FROM messages WHERE receiver_id = ? AND sender_type = 'system'");
$sys_check->bind_param("i", $admin_id);
$sys_check->execute();
$sys_count = $sys_check->get_result()->fetch_assoc()['count'];

if ($sys_count > 0) {
    // Prepend System "User" to the list
    array_unshift($tenant_list, [
        'id' => -1, // Special ID for System
        'fullname' => 'System Notifications',
        'room_label' => 'Admin'
    ]);
}

// Fetch message history if a tenant is selected
$messages = null;
if ($tenant_id != 0) {
    if ($tenant_id == -1) {
        // Fetch System Messages
        $messages_stmt = $conn->prepare("SELECT * FROM messages WHERE receiver_id = ? AND sender_type = 'system' ORDER BY created_at ASC");
        $messages_stmt->bind_param("i", $admin_id);
        $update_read_stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_type = 'system'");
        $update_read_stmt->bind_param("i", $admin_id);
    } else {
        // Fetch Tenant Messages
    $messages_stmt = $conn->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
    $messages_stmt->bind_param("iiii", $tenant_id, $admin_id, $admin_id, $tenant_id);
    $update_read_stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ? AND sender_type = 'tenant'");
    $update_read_stmt->bind_param("ii", $admin_id, $tenant_id);
    }
    
    $messages_stmt->execute();
    $messages = $messages_stmt->get_result();
    $update_read_stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Support — HouseMaster</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="side.css">
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="../tenant/tenant.css"> 
<body>

<?php include("navbar.php"); ?>

<div class="main p-4">
    <h3 class="fw-bold text-dark mb-3">💬 Tenant Support</h3>
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">Conversations</div>
                <div class="list-group list-group-flush">
                    <?php if (count($tenant_list) > 0): ?>
                        <?php foreach($tenant_list as $t): ?>
                            <a href="messages.php?tenant_id=<?php echo $t['id']; ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?php echo ($t['id'] == $tenant_id) ? 'active' : ''; ?>">
                                <span><?php echo htmlspecialchars($t['fullname']); ?></span>
                                <?php if ($t['room_label']): ?>
                                    <small class="badge bg-secondary rounded-pill"><?php echo htmlspecialchars($t['room_label']); ?></small>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="list-group-item">No conversations yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="chat-box mb-3">
                        <?php if ($messages): ?>
                            <?php if ($messages->num_rows > 0): ?>
                                <?php while($msg = $messages->fetch_assoc()): 
                                    // Determine if the message was sent by the current admin or received from the tenant
                                    $message_class = ($msg['sender_type'] === 'admin' && $msg['sender_id'] == $admin_id) ? 'tenant' : 'admin'; // 'tenant' class aligns right (sent), 'admin' class aligns left (received) in CSS usually, or vice versa depending on your CSS. Assuming 'tenant' style is for self/sent and 'admin' for received based on typical chat logic, but checking your CSS classes is important. Actually, usually 'me' vs 'other'. Let's stick to your existing logic: sender_type 'admin' means ME sending.
                                ?>
                                <div class="chat-message <?php echo $message_class; ?>" data-message-id="<?php echo $msg['id']; ?>">
                                    <div class="chat-bubble <?php echo $message_class; ?>">
                                        <?php echo htmlspecialchars($msg['message']); ?>
                                        <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">
                                            <?php echo date("h:i A", strtotime($msg['created_at'])); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-center text-muted">No messages in this conversation.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="text-center text-muted">Select a conversation to view messages.</p>
                        <?php endif; ?>
                    </div>

                    <?php if ($tenant_id > 0): // Only show input for real tenants, not System (-1) ?>
                    <form id="admin-chat-form" class="d-flex">
                        <input type="text" id="chat-message-input" class="form-control me-2" placeholder="Type your message..." required autocomplete="off" value="<?php echo htmlspecialchars($prefilled_message); ?>">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const chatBox = document.querySelector('.chat-box');
        const chatForm = document.getElementById('admin-chat-form');
        
        function scrollToBottom() {
            if(chatBox) {
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        }
        
        scrollToBottom();

        // If a tenant is selected, start polling for new messages
        const tenantId = <?php echo $tenant_id; ?>;
        if (tenantId != 0) {
            startChatPolling(tenantId);
        }

        if (chatForm) {
            chatForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const messageInput = document.getElementById('chat-message-input');
                const message = messageInput.value.trim();

                if (message === '' || tenantId === 0) {
                    return;
                }

                const formData = new FormData();
                formData.append('message', message);
                formData.append('tenant_id', tenantId);

                fetch('send_admin_message.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert('Error: ' + data.error);
                    } else {
                        // Clear input
                        messageInput.value = '';

                        // Append new message to chat box
                        const messageHtml = `
                            <div class="chat-message tenant" data-message-id="${data.id}">
                                <div class="chat-bubble tenant">
                                    ${escapeHtml(data.message)}
                                    <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${data.created_at}</div>
                                </div>
                            </div>`;
                        
                        const noMsgP = chatBox.querySelector('p');
                        if (noMsgP) noMsgP.remove();
                        
                        chatBox.insertAdjacentHTML('beforeend', messageHtml);
                        scrollToBottom();
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        }
    });

    // --- Chat Polling Logic ---
    let chatPollInterval;

    function startChatPolling(tenantId) {
        stopChatPolling(); 
        chatPollInterval = setInterval(() => fetchNewMessages(tenantId), 3000);
    }

    function stopChatPolling() {
        clearInterval(chatPollInterval);
    }

    function fetchNewMessages(tenantId) {
        const chatBox = document.querySelector('.chat-box');
        if (!chatBox) return;

        const lastMessage = chatBox.querySelector('.chat-message:last-child');
        const lastId = lastMessage ? lastMessage.getAttribute('data-message-id') : 0;

        // Use the correct path for the admin folder
        fetch(`../get_new_messages.php?tenant_id=${tenantId}&last_id=${lastId}`)
            .then(response => response.json())
            .then(messages => {
                if (messages.length > 0) {
                    messages.forEach(msg => {
                        // Only append messages from the other user (tenant)
                        if (msg.sender_type === 'tenant' || msg.sender_type === 'system') {
                            const messageHtml = `
                                <div class="chat-message admin" data-message-id="${msg.id}">
                                    <div class="chat-bubble admin">
                                        ${escapeHtml(msg.message)}
                                        <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${msg.created_at_formatted}</div>
                                    </div>
                                </div>`;
                            
                            const noMsgP = chatBox.querySelector('p');
                            if (noMsgP) noMsgP.remove();

                            chatBox.insertAdjacentHTML('beforeend', messageHtml);
                        }
                    });
                    chatBox.scrollTop = chatBox.scrollHeight;

                    // Update the global timestamp to prevent a full page reload
                    if (window.housemaster_last_update) {
                        window.housemaster_last_update = messages[messages.length - 1].created_at_timestamp;
                    }
                }
            });
    }

    function escapeHtml(unsafe) {
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
</script>
</body>
</html>
