<?php
session_start();
include __DIR__ . "/../config.php";

$error = ""; 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists in the database
        $stmt = $conn->prepare("SELECT id FROM admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "An admin with this email already exists.";
        } else {
            // Generate a unique boarding house code
            do {
                $boarding_code = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
                $code_check_stmt = $conn->prepare("SELECT id FROM admins WHERE boarding_code = ?");
                $code_check_stmt->bind_param("s", $boarding_code);
                $code_check_stmt->execute();
                $code_result = $code_check_stmt->get_result();
            } while ($code_result->num_rows > 0);

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $insert_stmt = $conn->prepare("INSERT INTO admins (name, email, password, boarding_code) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param("ssss", $name, $email, $hashed_password, $boarding_code);

            if ($insert_stmt->execute()) {
                // Automatically log in the new admin
                $_SESSION['admin_id'] = $insert_stmt->insert_id;
                $_SESSION['admin_name'] = $name;
                $_SESSION['boarding_code'] = $boarding_code;
                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Registration failed. Please try again.";
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Admin Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f7fa;
      font-family: 'Segoe UI', sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .register-box {
      width: 420px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      padding: 30px;
    }
    .register-box h3 {
      text-align: center;
      margin-bottom: 20px;
      color: #05445E;
      font-weight: bold;
    }
    .btn-primary {
      background: #05445E;
      border: none;
    }
    .btn-primary:hover {
      background: #032f40;
    }
    .logo {
      text-align: center;
      margin-bottom: 15px;
    } 
    .logo img {
        width: 120px;
        height: auto;
    }
  </style>
</head>
<body>
  <div class="register-box">
    <div class="logo">
      <img src="../assets/img/logo_bg removeed.png" alt="HouseMaster Logo">
    </div>
    <h3>Admin Registration</h3>

    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger py-2"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Confirm Password</label><input type="password" name="confirm_password" class="form-control" required></div>
      <button type="submit" class="btn btn-primary w-100">Register</button>
      <div class="text-center mt-3">
        <a href="admin-login.php">Already have an account? Login</a>
      </div>
    </form>
  </div>
</body>
</html>