<?php
session_start();
include __DIR__ . "/../config.php";

$error = ""; 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['boarding_code'] = $admin['boarding_code'];
            $_SESSION['admin_name'] = $admin['name'];

            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Admin not found.";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f7fa;
      font-family: 'Segoe UI', sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-box {
      width: 380px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      padding: 30px;
    }
    .login-box h3 {
      text-align: center;
      margin-bottom: 20px;
      color: #05445E;
      font-weight: bold;
    }
    .btn-primary {
      background: #05445E;
      border: none;
    }
    .btn-primary:hover {
      background: #032f40;
    }
    .logo {
      text-align: center;
      margin-bottom: 15px;
    } 
    .logo img {
        width: 120px;
        height: auto;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <div class="logo">
      <img src="../assets/img/logo_bg removeed.png" alt="HouseMaster Logo">
    </div>
    <h3>Admin Login</h3>

    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger py-2"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" id="email" class="form-control" required autofocus>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" id="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Login</button>
      <div class="text-center mt-3">
        <a href="admin-register.php">Create an Account</a> |
        <a href="admin-forgot-password.php">Forgot Password?</a>
      </div>
    </form>
  </div>
</body>
</html>
