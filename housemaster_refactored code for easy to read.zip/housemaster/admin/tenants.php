<?php
// This header file now handles session starting, config inclusion,
// and all account status enforcement (suspended/payment_due checks).
require_once 'header.php';

$admin_id = $_SESSION['admin_id'];
$message = "";
$boarding_code = $_SESSION['boarding_code'];

// Display session-based messages and set flag for broadcasting
if (isset($_SESSION['message'])) { // This block is hit on redirect after an action
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
    // This page was loaded after an action. The timestamp is already set by the action script.
}

// ✅ Fetch tenant status counts for the summary cards
$counts_stmt = $conn->prepare("SELECT status, COUNT(*) as count FROM tenants WHERE admin_id = ? GROUP BY status");
$counts_stmt->bind_param("i", $admin_id);
$counts_stmt->execute();
$counts_result = $counts_stmt->get_result();

$status_counts = [
    'active' => 0,
    'pending' => 0,
    'inactive' => 0,
    'unassigned' => 0
];
$total_tenants = 0;

while ($row_count = $counts_result->fetch_assoc()) {
    if (isset($status_counts[$row_count['status']])) {
        $status_counts[$row_count['status']] = $row_count['count'];
    }
    $total_tenants += $row_count['count'];
}

// Handle Generate Bill
if (isset($_POST['generate_bill']) && !in_array($account_status, ['pending', 'restricted'])) {
    $tenant_id = $_POST['tenant_id'];
    $rental_rate = $_POST['rental_rate'];

    if (empty($rental_rate)) {
        $message = "<div class='alert alert-danger'>Cannot generate bill. Tenant is not assigned to a room with a rental rate.</div>";
    } else {
        // Find the last due date for this tenant, or use today if none exists
        $last_due_stmt = $conn->prepare("SELECT MAX(due_date) as last_due FROM payments WHERE tenant_id = ?");
        $last_due_stmt->bind_param("i", $tenant_id);
        $last_due_stmt->execute();
        $last_due_date = $last_due_stmt->get_result()->fetch_assoc()['last_due'];

        $next_due_date = $last_due_date ? date('Y-m-d', strtotime($last_due_date . ' +1 month')) : date('Y-m-d', strtotime('+1 month'));

        // Insert the new payment record
        $insert_stmt = $conn->prepare("INSERT INTO payments (tenant_id, admin_id, boarding_code, amount, due_date, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $insert_stmt->bind_param("iisds", $tenant_id, $admin_id, $boarding_code, $rental_rate, $next_due_date);
        $insert_stmt->execute();
        $conn->query("UPDATE system_state SET state_value = UNIX_TIMESTAMP() WHERE state_key = 'last_update_timestamp'");
        $_SESSION['message'] = "<div class='alert alert-success'>Bill generated successfully.</div>";
        header("Location: tenants.php" . (!empty($_GET['status']) ? "?status=" . $_GET['status'] : ""));
        exit();
    }
}

// Handle Approve Tenant & Generate First Bill
if (isset($_POST['approve_and_bill']) && !in_array($account_status, ['pending', 'restricted'])) {
    $tenant_id_to_approve = $_POST['tenant_id'];
    $start_date = $_POST['start_date'];
    $rental_rate = $_POST['rental_rate'];
    $start_boarding_date = $_POST['start_date']; // Use start_date for the tenant's record
    $requested_room_id = $_POST['requested_room_id'];

    if (empty($start_date) || empty($rental_rate)) {
        $message = "<div class='alert alert-danger'>Start date and rental rate are required to approve and bill a tenant.</div>";
    } else {
        // 1. Update tenant status to active and set start_boarding_date
        $approve_stmt = $conn->prepare("UPDATE tenants SET status = 'active', start_boarding_date = ? WHERE id = ? AND admin_id = ? AND status = 'pending'");
        $approve_stmt->bind_param("sii", $start_boarding_date, $tenant_id_to_approve, $admin_id);
        $approve_stmt->execute();

        // 2. Assign tenant to the requested room
        if (!empty($requested_room_id)) {
            $assign_stmt = $conn->prepare("INSERT INTO tenant_rooms (tenant_id, room_id) VALUES (?, ?)");
            $assign_stmt->bind_param("ii", $tenant_id_to_approve, $requested_room_id);
            $assign_stmt->execute();
        }

        // 3. Calculate the due date for the next month
        $due_date = date('Y-m-d', strtotime($start_date . ' +1 month'));

        // 4. Insert the first payment record with the calculated due date
        $insert_bill_stmt = $conn->prepare("INSERT INTO payments (tenant_id, admin_id, boarding_code, amount, due_date, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $insert_bill_stmt->bind_param("iisds", $tenant_id_to_approve, $admin_id, $boarding_code, $rental_rate, $due_date);
        $insert_bill_stmt->execute();

        $conn->query("UPDATE system_state SET state_value = UNIX_TIMESTAMP() WHERE state_key = 'last_update_timestamp'");
        $_SESSION['message'] = "<div class='alert alert-success'>Tenant approved and first bill generated.</div>";
        // Redirect to clear POST data and show the updated list, preserving the filter
        header("Location: tenants.php?status=active");
        exit();
    }
}

// Handle Deny Tenant
if (isset($_POST['deny_tenant']) && !in_array($account_status, ['pending', 'restricted'])) {
    $tenant_id_to_deny = $_POST['tenant_id'];
    // Security check: ensure admin can only deny their own tenants
    $deny_stmt = $conn->prepare("DELETE FROM tenants WHERE id = ? AND admin_id = ? AND status = 'pending'");
    $deny_stmt->bind_param("ii", $tenant_id_to_deny, $admin_id);
    if ($deny_stmt->execute() && $deny_stmt->affected_rows > 0) {
        $conn->query("UPDATE system_state SET state_value = UNIX_TIMESTAMP() WHERE state_key = 'last_update_timestamp'");
        $_SESSION['message'] = "<div class='alert alert-info'>Pending tenant application has been denied and removed.</div>";
    } else {
        $_SESSION['message'] = "<div class='alert alert-danger'>Error denying tenant.</div>";
    }
    header("Location: tenants.php" . (!empty($_GET['status']) ? "?status=" . $_GET['status'] : ""));
    exit();
}

// Handle Tenant Update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_tenant']) && !in_array($account_status, ['pending', 'restricted'])) {
    $tenant_id_to_update = $_POST['tenant_id'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $age = $_POST['age'];
    $status = $_POST['status'];
    $start_boarding_date = $_POST['start_boarding_date'];
    $new_room_id = $_POST['room_id'];
    $original_start_date = $_POST['original_start_date']; // Keep for due date recalculation
    $emergency_contact_person = $_POST['emergency_contact_person'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];

    // Security check: ensure admin can only edit their own tenants
    $update_stmt = $conn->prepare("UPDATE tenants SET fullname = ?, email = ?, phone = ?, age = ?, status = ?, start_boarding_date = ?, emergency_contact_person = ?, emergency_contact_phone = ?, boarding_code = ? WHERE id = ? AND admin_id = ?");
    $update_stmt->bind_param("sssssssssii", $fullname, $email, $phone, $age, $status, $start_boarding_date, $emergency_contact_person, $emergency_contact_phone, $boarding_code, $tenant_id_to_update, $admin_id);

    // Only proceed if there wasn't an error during approval validation
    if (empty($message) && $update_stmt->execute()) {

        // ✅ If status is changed to 'inactive', unassign from room and delete pending payments
        if ($status === 'inactive') {
            // We no longer delete the room assignment. Instead, we'll filter occupancy counts.
            // $delete_assignment = $conn->prepare("DELETE FROM tenant_rooms WHERE tenant_id = ?");
            // $delete_assignment->bind_param("i", $tenant_id_to_update);
            // $delete_assignment->execute();
            
            $delete_pending_payments = $conn->prepare("DELETE FROM payments WHERE tenant_id = ? AND status = 'pending'");
            $delete_pending_payments->bind_param("i", $tenant_id_to_update);
            $delete_pending_payments->execute();
        }
        // If the start boarding date was changed for an existing active tenant, update their next due date.
        if ($status === 'active' && $start_boarding_date !== $original_start_date) {
            // Find the earliest pending payment for this tenant
            $payment_stmt = $conn->prepare("SELECT id, due_date FROM payments WHERE tenant_id = ? AND status = 'pending' ORDER BY due_date ASC LIMIT 1");
            $payment_stmt->bind_param("i", $tenant_id_to_update);
            $payment_stmt->execute();
            $payment_result = $payment_stmt->get_result();

            if ($payment_result->num_rows > 0) {
                $payment = $payment_result->fetch_assoc();
                $payment_id = $payment['id'];
                
                // Calculate the month difference between the original start date and the original due date
                $original_start = new DateTime($original_start_date);
                $original_due = new DateTime($payment['due_date']);
                $interval = $original_start->diff($original_due);
                $months_diff = $interval->y * 12 + $interval->m;

                // Calculate the new due date based on the new start date plus the month difference
                $new_start = new DateTime($start_boarding_date);
                $new_start->add(new DateInterval("P{$months_diff}M"));
                $new_due_date = $new_start->format('Y-m-d');

                $update_payment_stmt = $conn->prepare("UPDATE payments SET due_date = ? WHERE id = ?");
                $update_payment_stmt->bind_param("si", $new_due_date, $payment_id);
                $update_payment_stmt->execute();
            }
        }

        $_SESSION['message'] = "<div class='alert alert-success'>Tenant details updated successfully.</div>";
        header("Location: tenants.php" . (!empty($_GET['status']) ? "?status=" . $_GET['status'] : ""));
        exit(); // Exit immediately after setting the redirect header
        // Handle room assignment change
        // First, remove any existing room assignment for this tenant
        $delete_stmt = $conn->prepare("DELETE FROM tenant_rooms WHERE tenant_id = ?");
        $delete_stmt->bind_param("i", $tenant_id_to_update);
        $delete_stmt->execute();

        if ($new_room_id === 'unassign') {
            // Unassign the tenant and delete their pending payments
            $update_status_stmt = $conn->prepare("UPDATE tenants SET status='unassigned' WHERE id = ? AND admin_id = ?");
            $update_status_stmt->bind_param("ii", $tenant_id_to_update, $admin_id);
            $update_status_stmt->execute();

            // If unassigned, delete pending payments
            $delete_payments = $conn->prepare("DELETE FROM payments WHERE tenant_id = ? AND status = 'pending'");
            $delete_payments->bind_param("i", $tenant_id_to_update);
            $delete_payments->execute();
        } else if (!empty($new_room_id)) {
            // Assign to the new room
            $conn->query("UPDATE system_state SET state_value = UNIX_TIMESTAMP() WHERE state_key = 'last_update_timestamp'");
            $assign_stmt = $conn->prepare("INSERT INTO tenant_rooms (tenant_id, room_id) VALUES (?, ?)");
            $assign_stmt->bind_param("ii", $tenant_id_to_update, $new_room_id);
            $assign_stmt->execute();
        }
    } elseif (empty($message)) {
        $message = "<div class='alert alert-danger'>Error updating tenant. The email might already be in use by another tenant.</div>";
    }
}

// Handle status filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : "";

// Build query with filter
$sql = "
    SELECT t.id, t.fullname, t.email, t.phone, t.status, t.created_at, r.id as room_id, r.room_label, r.rental_rate, t.age, t.emergency_contact_person, t.emergency_contact_phone,
    t.start_boarding_date, t.requested_room_id, (SELECT MIN(due_date) FROM payments WHERE tenant_id = t.id AND status = 'pending') AS next_due_date
    FROM tenants t
    LEFT JOIN tenant_rooms tr ON t.id = tr.tenant_id
    LEFT JOIN rooms r ON tr.room_id = r.id
    WHERE t.admin_id = ?
";

$params = [$admin_id];
$types = "i";

if (!empty($status_filter)) {
    $sql .= " AND t.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

$sql .= " ORDER BY t.fullname ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Fetch all rooms with their occupancy for the dropdown
$all_rooms_stmt = $conn->prepare("
    SELECT r.id, r.room_label, r.capacity, r.rental_rate, COUNT(tr.id) AS tenants 
    FROM rooms r LEFT JOIN tenant_rooms tr ON r.id = tr.room_id 
    WHERE r.boarding_code = ? GROUP BY r.id ORDER BY r.room_label ASC");
$all_rooms_stmt->bind_param("s", $boarding_code);
$all_rooms_stmt->execute();
$all_rooms_for_assignment = $all_rooms_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<title>HouseMaster — Tenants Profile</title>
<link rel="stylesheet" href="side.css">
<link rel="stylesheet" href="main.css">
  <!-- Sidebar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="main p-4">
    <h3 class="fw-bold text-dark">👥 Tenants Profile</h3>

    <?php if (!empty($message)): ?>
        <?php echo $message; ?>
    <?php endif; ?>

    <!-- Status Summary Info -->
    <div class="d-flex flex-wrap align-items-center gap-3 mb-4">
        <span class="fw-bold">Total Tenants: <span class="badge bg-primary rounded-pill"><?php echo $total_tenants; ?></span></span>
        <span class="ms-3">Active: <span class="badge bg-success rounded-pill"><?php echo $status_counts['active']; ?></span></span>
        <span>Pending: <span class="badge bg-warning rounded-pill"><?php echo $status_counts['pending']; ?></span></span>
        <span>Inactive: <span class="badge bg-danger rounded-pill"><?php echo $status_counts['inactive']; ?></span></span>
    </div>

    <!-- Filter -->
    <form method="GET" class="mb-3">
      <div class="row g-2">
        <div class="col-md-3">
          <select name="status" class="form-select">
            <option value="">All</option>
            <option value="pending" <?php if ($status_filter == "pending") echo "selected"; ?>>Pending</option>
            <option value="active" <?php if ($status_filter == "active") echo "selected"; ?>>Active</option>
            <option value="inactive" <?php if ($status_filter == "inactive") echo "selected"; ?>>Inactive</option>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Apply</button>
        </div>
        <div class="col-md-2">
          <a href="tenants.php" class="btn btn-secondary w-100">Reset</a>
        </div>
      </div>
    </form>

    <div class="card shadow-sm border-0">
      <div class="card-body">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Room</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Status</th>
              <th>Rent Days Left</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result->num_rows > 0): ?>
              <?php $i=1; while ($row = $result->fetch_assoc()): ?>
                <?php
                  // Moved this calculation to the top of the loop so it's available for both the table row and the modal.
                  $days_remaining = null;
                  if ($row['next_due_date']) {
                      $today = new DateTime();
                      // Set time to 00:00:00 to compare dates only, avoiding time-of-day issues.
                      $today->setTime(0, 0, 0);
                      $dueDate = new DateTime($row['next_due_date']);
                      $dueDate->setTime(0, 0, 0);
                      $interval = $today->diff($dueDate);
                      $days_remaining = (int)$interval->format('%r%a');
                  }
                ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                  <td><?php echo $row['room_label'] ? htmlspecialchars($row['room_label']) : '<span class="text-muted">Unassigned</span>'; ?></td>
                  <td><?php echo htmlspecialchars($row['phone']); ?></td>
                  <td><?php echo htmlspecialchars($row['email']); ?></td>
                  <td>
                    <?php
                      $status = $row['status'];
                      $badgeClass = match($status) {
                          "active" => "success",
                          "pending" => "warning",
                          "inactive" => "danger",
                          "unassigned" => "secondary",
                          default => "dark"
                      };
                    ?>
                    <span class="badge bg-<?php echo $badgeClass; ?>"><?php echo ucfirst($status); ?></span>
                  </td>
                  <td>
                    <?php
                      if ($days_remaining !== null && $account_status !== 'pending') {
                          if ($days_remaining < 0) {
                              echo '<span class="badge bg-danger">Overdue by ' . abs($days_remaining) . ' days</span>';
                          } elseif ($days_remaining <= 7) {
                              echo '<span class="badge bg-warning">' . $days_remaining . ' days</span>';
                          } else {
                              echo '<span class="badge bg-info">' . $days_remaining . ' days</span>';
                          }
                      } else {
                          echo '<span class="text-muted">No pending payment</span>';
                      }
                    ?>
                  </td>
                  <td>
                    <?php if ($row['status'] === 'pending' && !in_array($account_status, ['pending', 'restricted'])): ?>
                        <button type="button" class="btn btn-sm btn-success" title="Approve Tenant" 
                                data-bs-toggle="modal" 
                                data-bs-target="#approveModal"
                                data-tenant-id="<?php echo $row['id']; ?>"
                                data-tenant-name="<?php echo htmlspecialchars($row['fullname']); ?>"
                                data-requested-room-id="<?php echo $row['requested_room_id']; ?>"
                                <?php if (empty($row['requested_room_id'])) echo 'disabled title="Tenant has not requested a room."'; ?>>
                            <i class="fas fa-check"></i></button>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to deny and delete this tenant?');" title="Deny Tenant">
                            <input type="hidden" name="tenant_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="deny_tenant" class="btn btn-sm btn-danger" title="Deny Tenant"><i class="fas fa-times"></i></button>
                        </form>
                    <?php else: ?>
                    <?php endif; ?>
                    <!-- Unified View Button for all statuses -->
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#tenant<?php echo $row['id']; ?>" title="View Details"><i class="fas fa-eye"></i></button>
                    <?php if ($row['status'] !== 'pending'): ?>
                      <a href="payments.php?tenant_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-info" title="View Payment History"><i class="fas fa-history"></i></a>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="8" class="text-center text-muted">No tenants found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <footer class="mt-4">HouseMaster © 2025 — Boarding House & Dormitory Management System</footer>
  </div>

  <!-- Modals Section -->
  <?php
    // Reset the result pointer and loop again to generate modals outside the table
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()):
      // Recalculate days_remaining for this scope
      $days_remaining = null;
      if ($row['next_due_date']) {
          $today = new DateTime();
          $today->setTime(0, 0, 0);
          $dueDate = new DateTime($row['next_due_date']);
          $dueDate->setTime(0, 0, 0);
          $interval = $today->diff($dueDate);
          $days_remaining = (int)$interval->format('%r%a');
      }
  ?>
      <!-- Tenant Modal -->
      <div class="modal fade" id="tenant<?php echo $row['id']; ?>" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Tenant Details — <?php echo htmlspecialchars($row['fullname']); ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <p><b>Name:</b> <?php echo htmlspecialchars($row['fullname']); ?></p>
              <p><b>Room:</b> <?php echo $row['room_label'] ? htmlspecialchars($row['room_label']) : 'Unassigned'; ?></p>
              <p><b>Contact:</b> <?php echo htmlspecialchars($row['phone']); ?></p>
              <p><b>Email:</b> <?php echo htmlspecialchars($row['email']); ?></p>
              <p><b>Age:</b> <?php echo htmlspecialchars($row['age']); ?></p>
              <p><b>Emergency Contact:</b> <?php echo htmlspecialchars($row['emergency_contact_person']); ?></p>
              <p><b>Emergency Phone:</b> <?php echo htmlspecialchars($row['emergency_contact_phone']); ?></p>
              <p><b>Status:</b> <?php echo ucfirst($row['status']); ?></p>
              <p><b>Joined:</b> <?php echo date("M d, Y", strtotime($row['created_at'])); ?></p>
            </div>
            <div class="modal-footer">
              <?php if ($row['status'] === 'pending' && !in_array($account_status, ['pending', 'restricted'])): ?>
                  <button type="button" class="btn btn-success" title="Approve Tenant" 
                          data-bs-dismiss="modal"
                          data-bs-toggle="modal" 
                          data-bs-target="#approveModal"
                          data-tenant-id="<?php echo $row['id']; ?>"
                          data-tenant-name="<?php echo htmlspecialchars($row['fullname']); ?>"
                          data-requested-room-id="<?php echo $row['requested_room_id']; ?>"
                          <?php if (empty($row['requested_room_id'])) echo 'disabled title="Tenant has not requested a room."'; ?>>
                      <i class="fas fa-check"></i>
                  </button>
                  <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to deny and delete this tenant?');">
                      <input type="hidden" name="tenant_id" value="<?php echo $row['id']; ?>">
                      <button type="submit" name="deny_tenant" class="btn btn-danger" title="Deny Tenant"><i class="fas fa-times"></i></button>
                  </form>
              <?php else: ?>
                  <button type="button" class="btn btn-info" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#paymentHistoryModal<?php echo $row['id']; ?>" title="Payment History">
                      <i class="fas fa-history"></i>
                  </button>
                  <?php if ($row['status'] !== 'inactive' && !in_array($account_status, ['pending', 'restricted'])): ?>
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#editTenant<?php echo $row['id']; ?>" title="Edit Tenant">
                        <i class="fas fa-edit"></i>
                    </button>
                  <?php endif; ?>
              <?php endif; ?>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Edit Tenant Modal -->
      <div class="modal fade" id="editTenant<?php echo $row['id']; ?>" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <form method="POST">
              <div class="modal-header">
                <h5 class="modal-title">Edit Tenant — <?php echo htmlspecialchars($row['fullname']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                  <input type="hidden" name="tenant_id" value="<?php echo $row['id']; ?>">
                  <input type="hidden" name="original_start_date" value="<?php echo htmlspecialchars($row['start_boarding_date']); ?>">
                  <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="fullname" class="form-control" value="<?php echo htmlspecialchars($row['fullname']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($row['email']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($row['phone']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Age</label><input type="number" name="age" class="form-control" value="<?php echo htmlspecialchars($row['age']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Emergency Contact Person</label><input type="text" name="emergency_contact_person" class="form-control" value="<?php echo htmlspecialchars($row['emergency_contact_person']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Emergency Contact Phone</label><input type="text" name="emergency_contact_phone" class="form-control" value="<?php echo htmlspecialchars($row['emergency_contact_phone']); ?>" required></div>
                  <div class="mb-3"><label class="form-label">Start Boarding Date</label><input type="date" name="start_boarding_date" class="form-control" value="<?php echo htmlspecialchars($row['start_boarding_date'] ?? ''); ?>" <?php if($row['status'] !== 'pending') echo 'required'; ?>></div>
                  <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" required <?php if ($row['status'] == 'inactive') echo 'disabled'; ?>>
                      <option value="active" <?php if ($row['status'] == 'active') echo 'selected'; ?>>Active</option><option value="inactive" <?php if ($row['status'] == 'inactive') echo 'selected'; ?>>Inactive</option>
                    </select>
                  </div>
                  <hr>
                  <div class="mb-3"><label class="form-label">Room Assignment</label><select name="room_id" class="form-select"><option value="unassign">Unassign</option><?php foreach ($all_rooms_for_assignment as $room_option): ?><?php $is_available = $room_option['tenants'] < $room_option['capacity']; $is_current_room = $room_option['id'] == $row['room_id']; if ($is_available || $is_current_room): ?><option value="<?php echo $room_option['id']; ?>" <?php if ($is_current_room) echo 'selected'; ?>><?php echo htmlspecialchars($room_option['room_label']); ?> (<?php echo $room_option['tenants']; ?>/<?php echo $room_option['capacity']; ?>)</option><?php endif; ?><?php endforeach; ?></select><div class="form-text">Changing this will move the tenant to a new room or unassign them.</div></div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="update_tenant" class="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Payment History Modal -->
      <div class="modal fade" id="paymentHistoryModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="paymentHistoryModalLabel<?php echo $row['id']; ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="paymentHistoryModalLabel<?php echo $row['id']; ?>">Payment History: <?php echo htmlspecialchars($row['fullname']); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body">
              <!-- Filters for the modal -->
              <div class="row g-2 mb-3">
                  <div class="col-md-5">
                      <select class="form-select payment-history-filter" data-tenant-id="<?php echo $row['id']; ?>" data-filter-type="status">
                          <option value="">-- Filter by Status --</option>
                          <option value="pending">Pending</option>
                          <option value="overdue">Overdue</option>
                          <option value="paid">Paid</option>
                      </select>
                  </div>
                  <div class="col-md-5">
                      <select class="form-select payment-history-filter" data-tenant-id="<?php echo $row['id']; ?>" data-filter-type="month">
                          <option value="">-- Filter by Month --</option>
                          <?php
                          $months = ['01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April', '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August', '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'];
                          foreach ($months as $num => $name) {
                              echo "<option value='{$num}'>{$name}</option>";
                          }
                          ?>
                      </select>
                  </div>
              </div>

              <table class="table table-striped">
                <thead><tr><th>Amount</th><th>Due Date</th><th>Status</th></tr></thead>
                <tbody id="paymentHistoryContent<?php echo $row['id']; ?>">
                  <!-- Content will be loaded via AJAX -->
                  <tr><td colspan="3" class="text-center"><div class="spinner-border spinner-border-sm"></div> Loading...</td></tr>
                </tbody>
              </table>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div>
          </div>
        </div>
      </div>
  <?php endwhile; ?>

  <!-- Approve & Bill Modal -->
  <div class="modal fade" id="approveModal" tabindex="-1" aria-labelledby="approveModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST">
          <div class="modal-header">
            <h5 class="modal-title" id="approveModalLabel">Approve Tenant & Generate First Bill</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>You are approving <strong id="approveTenantName"></strong>. Please set their start boarding date to generate their first bill.</p>
            <input type="hidden" name="tenant_id" id="approveTenantId">
            <input type="hidden" name="rental_rate" id="approveRentalRate">
            <input type="hidden" name="requested_room_id" id="approveRequestedRoomId">
            
            <div class="mb-3">
              <label for="startDate" class="form-label">Start Boarding Date</label>
              <input type="date" class="form-control" id="startDate" name="start_date" required>
            </div>
            <div class="form-text">The first bill will be due one month after this date.</div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" name="approve_and_bill" class="btn btn-success">Confirm Approval</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Custom polling for auto-refresh -->
  <script>
    // Pass the server's last update timestamp to the JavaScript poller.
    <?php
        $ts_stmt = $conn->query("SELECT state_value FROM system_state WHERE state_key = 'last_update_timestamp'");
        $current_ts = $ts_stmt->fetch_assoc()['state_value'];
    ?>
    window.housemaster_last_update = <?php echo $current_ts ?: 0; ?>;
  </script>
  <script src="assets/js/autoupdate.js"></script>
  <script>
    <?php
      $room_rates_map = [];
      foreach ($all_rooms_for_assignment as $room) {
          $room_rates_map[$room['id']] = $room['rental_rate'];
      }
    ?>
    const roomRentalRates = <?php echo json_encode($room_rates_map); ?>;

    // Pass data to the Approve & Bill modal
    const approveModal = document.getElementById('approveModal');
    approveModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const requestedRoomId = button.getAttribute('data-requested-room-id');

        document.getElementById('approveTenantId').value = button.getAttribute('data-tenant-id');
        document.getElementById('approveRequestedRoomId').value = requestedRoomId;
        document.getElementById('approveTenantName').textContent = button.getAttribute('data-tenant-name');
        
        // Set the rental rate based on the requested room
        document.getElementById('approveRentalRate').value = roomRentalRates[requestedRoomId] || '';

        // Set the start date to today in a cross-browser compatible way (YYYY-MM-DD)
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const dd = String(today.getDate()).padStart(2, '0');
        document.getElementById('startDate').value = `${yyyy}-${mm}-${dd}`;
    });

    // --- Payment History Modal AJAX ---
    const paymentHistoryModals = document.querySelectorAll('.modal[id^="paymentHistoryModal"]');

    // Function to load payment history
    function loadPaymentHistory(tenantId, status = '', month = '') {
        const contentArea = document.getElementById(`paymentHistoryContent${tenantId}`);
        if (!contentArea) return;

        contentArea.innerHTML = '<tr><td colspan="3" class="text-center"><div class="spinner-border spinner-border-sm"></div> Loading...</td></tr>';
        
        const url = `get_payment_history.php?tenant_id=${tenantId}&status=${status}&month=${month}`;

        fetch(url)
            .then(response => response.text())
            .then(data => {
                contentArea.innerHTML = data;
            })
            .catch(error => {
                contentArea.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>';
                console.error('Error:', error);
            });
    }

    // Add event listeners to all payment history modals
    paymentHistoryModals.forEach(modal => {
        const tenantId = modal.id.replace('paymentHistoryModal', '');
        modal.addEventListener('show.bs.modal', function () {
            // Load initial data when modal is shown
            loadPaymentHistory(tenantId);
        });

        // Add listeners to filter dropdowns inside this modal
        modal.querySelectorAll('.payment-history-filter').forEach(filterInput => {
            filterInput.addEventListener('change', function() {
                const status = modal.querySelector('[data-filter-type="status"]').value;
                const month = modal.querySelector('[data-filter-type="month"]').value;
                loadPaymentHistory(tenantId, status, month);
            });
        });
    });
  </script>
</body>
</html>
