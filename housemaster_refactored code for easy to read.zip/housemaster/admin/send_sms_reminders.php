<?php
// This script should be placed in a 'cron' folder for organization.
// It is intended to be run automatically by a scheduler (like a cron job).

include __DIR__ . "/../config.php";

// =================================================
// TextBee SMS Gateway Configuration
// =================================================
// 1. Make sure your phone's IP address is correct. If using a mobile hotspot, it's usually 192.168.43.1
define('TEXTBEE_GATEWAY_URL', 'http://192.168.43.1:8080/api/send_sms');

// 2. VERY IMPORTANT: Replace 'YOUR_TEXTBEE_API_KEY' with the actual key from your TextBee app's settings.
define('TEXTBEE_API_KEY', 'd2649afd-3535-4563-a5be-a76bc1fc444c'); 

// How many days in advance to send the reminder.
define('REMINDER_DAYS_BEFORE_DUE', 3);


echo "Starting SMS reminder script for " . date('Y-m-d') . "\n";

// =================================================
// 1. Find tenants with upcoming due dates
// =================================================

$reminder_date = date('Y-m-d', strtotime('+' . REMINDER_DAYS_BEFORE_DUE . ' days'));

// Find all 'pending' payments that are due in REMINDER_DAYS_BEFORE_DUE days.
$stmt = $conn->prepare("
    SELECT t.fullname, t.phone, p.amount, p.due_date
    FROM payments p
    JOIN tenants t ON p.tenant_id = t.id
    WHERE p.due_date = ? AND p.status = 'pending'
");
$stmt->bind_param("s", $reminder_date);
$stmt->execute();
$payments_to_remind = $stmt->get_result();

if ($payments_to_remind->num_rows === 0) {
    echo "No pending payments found for " . $reminder_date . ". Exiting.\n";
    exit;
}

echo "Found " . $payments_to_remind->num_rows . " tenants to remind.\n";

// =================================================
// 2. Loop through and send SMS via the gateway
// =================================================

while ($payment = $payments_to_remind->fetch_assoc()) {
    // IMPORTANT: The phone number must be in the correct format for your country.
    // For the Philippines, it's often '09xxxxxxxxx' or '+639xxxxxxxxx'.
    // Check what format the SMS Gateway app expects.
    $tenant_phone = $payment['phone'];

    $message_body = "Hi " . $payment['fullname'] . ", a friendly reminder that your payment of ₱" . number_format($payment['amount']) . " is due on " . date("M d, Y", strtotime($payment['due_date'])) . ". - HouseMaster";

    // Prepare the data for the POST request
    $postData = [
        'phone_number' => $tenant_phone,
        'sms_content'  => $message_body,
        'api_key'      => 'TEXTBEE_API_KEY'
    ];

    // Use cURL to send the HTTP request to the Android gateway
    $ch = curl_init(TEXTBEE_GATEWAY_URL);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // Set a timeout to prevent the script from hanging indefinitely
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // 3. Log the result
    if ($http_code == 200) {
        echo "Successfully sent reminder to " . $payment['fullname'] . " (" . $tenant_phone . ")\n";
    } else {
        echo "ERROR: Failed to send SMS to " . $payment['fullname'] . ". Gateway response code: " . $http_code . ". Response: " . $response . "\n";
    }

    // Add a small delay to avoid overwhelming the gateway app
    sleep(2);
}

echo "SMS reminder script finished.\n";
?>