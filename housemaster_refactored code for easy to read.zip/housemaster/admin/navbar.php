
<?php
// Ensure session is started and config is included.
// This check prevents errors if navbar.php is included in a file that hasn't started a session.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($conn)) {
    
    include_once __DIR__ . "/../config.php";
}

$admin_id_for_nav = $_SESSION['admin_id'] ?? 0;

// 1. Count unread messages for the admin
$unread_stmt = $conn->prepare("SELECT COUNT(id) AS count FROM messages WHERE receiver_id = ? AND (sender_type = 'tenant' OR sender_type = 'system') AND is_read = 0");
$unread_stmt->bind_param("i", $admin_id_for_nav);
$unread_stmt->execute();
$unread_messages_count = $unread_stmt->get_result()->fetch_assoc()['count'];

// 2. Count pending tenants for the admin
$pending_stmt = $conn->prepare("SELECT COUNT(id) AS count FROM tenants WHERE admin_id = ? AND status = 'pending'");
$pending_stmt->bind_param("i", $admin_id_for_nav);
$pending_stmt->execute();
$pending_tenants_count = $pending_stmt->get_result()->fetch_assoc()['count'];

// 3. Count overdue payments for the admin
$overdue_stmt = $conn->prepare("SELECT COUNT(p.id) AS count FROM payments p JOIN tenants t ON p.tenant_id = t.id WHERE t.admin_id = ? AND p.status = 'pending' AND p.due_date < CURDATE()");
$overdue_stmt->bind_param("i", $admin_id_for_nav);
$overdue_stmt->execute();
$overdue_payments_count = $overdue_stmt->get_result()->fetch_assoc()['count'];
?>

<?php if (isset($account_status) && $account_status === 'pending'): ?>
<div class="alert alert-warning text-center m-0 rounded-0 fixed-top" style="z-index: 1030; left: 240px;">
    <?php if (empty($admin_account['payment_proof'])): ?>
        <i class="fas fa-exclamation-circle"></i> <strong>Account Pending:</strong> You have read-only access. <a href="#" class="alert-link" data-bs-toggle="modal" data-bs-target="#paymentVerificationModal">Click here to verify your payment</a> to unlock full access.
    <?php else: ?>
        <i class="fas fa-hourglass-half"></i> <strong>Verification In Progress:</strong> You have read-only access while we verify your payment proof.
    <?php endif; ?>
</div>
<style>.main, .main-content { margin-top: 40px; }</style>
<?php endif; ?>

<?php if (isset($account_status) && $account_status === 'restricted'): ?>
<div class="alert alert-danger text-center m-0 rounded-0 fixed-top" style="z-index: 1030; left: 240px;">
    <i class="fas fa-ban"></i> <strong>Account Restricted:</strong> Your account has been restricted. You have read-only access. <a href="#" class="alert-link" data-bs-toggle="modal" data-bs-target="#paymentVerificationModal">Click here to renew your subscription</a>.
</div>
<style>.main, .main-content { margin-top: 40px; }</style>
<?php endif; ?>

<?php if (isset($show_approval_notification) && $show_approval_notification): ?>
<div class="alert alert-success alert-dismissible fade show text-center m-0 rounded-0 fixed-top" role="alert" style="z-index: 1030; left: 240px;">
    <i class="fas fa-check-circle"></i> <strong>Congratulations!</strong> Your account has been approved by the Super Admin. You now have full access.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<style>.main, .main-content { margin-top: 40px; }</style>
<?php endif; ?>

<div class="sidebar">
  <div class="logo-hold">
    <img class="logo"  src="../assets/img/logo_bg removeed.png" alt="" srcset="">

</div>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
  <a href="tenants.php?status=pending"><i class="fas fa-users"></i> Tenants Profile <?php if ($pending_tenants_count > 0) echo '<span class="notification-badge"></span>'; ?></a>
  <a href="rooms.php"><i class="fas fa-home"></i> Room Management</a>
  <a href="payments.php?status=overdue"><i class="fas fa-money-bill"></i> Payments <?php if ($overdue_payments_count > 0) echo '<span class="notification-badge"></span>'; ?></a>
  <a href="messages.php"><i class="fas fa-envelope"></i> Messages <?php if ($unread_messages_count > 0) echo '<span class="notification-badge"></span>'; ?></a>
  <a href="notices.php"><i class="fas fa-bullhorn"></i> Announcements</a>
  <a href="admin-logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Payment Verification Modal -->
<div class="modal fade" id="paymentVerificationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 15px; overflow: hidden;">
            <div class="modal-header border-0 d-flex flex-column align-items-center justify-content-center pt-4 pb-0" style="background-color: #f8f9fa;">
                <img src="../assets/img/logo_bg removeed.png" alt="HouseMaster Logo" style="width: 80px; height: auto; margin-bottom: 10px;">
                <h5 class="modal-title fw-bold" style="color: #05445E;">Payment Verification</h5>
                <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4 text-start" style="background-color: #f8f9fa;">
                <form action="admin-payment.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-secondary small text-uppercase">Select Payment Method</label>
                        <select id="modalPaymentMethod" class="form-select shadow-none" onchange="toggleModalPaymentDetails()" style="border-color: #ced4da;">
                            <option value="" selected disabled>Choose an option...</option>
                            <option value="gcash">GCash</option>
                            <option value="bank">Bank Transfer</option>
                        </select>
                    </div>

                    <div id="modalGcashDetails" class="mb-4 p-3 bg-white rounded border shadow-sm d-none">
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-mobile-alt fa-lg me-2" style="color: #05445E;"></i>
                            <h6 class="fw-bold mb-0" style="color: #05445E;">GCash Payment</h6>
                        </div>
                        <p class="small text-muted mb-2">Please send your subscription payment to:</p>
                        <ul class="list-unstyled small mb-0 ps-2 border-start border-3" style="border-color: #05445E !important;">
                            <li class="mb-1"><span class="text-muted">Number:</span> <strong class="text-dark">0912 345 6789</strong></li>
                            <li><span class="text-muted">Name:</span> <strong class="text-dark">HouseMaster</strong></li>
                        </ul>
                    </div>

                    <div id="modalBankDetails" class="mb-4 p-3 bg-white rounded border shadow-sm d-none">
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-university fa-lg me-2" style="color: #05445E;"></i>
                            <h6 class="fw-bold mb-0" style="color: #05445E;">Bank Transfer</h6>
                        </div>
                        <p class="small text-muted mb-2">Please deposit your payment to:</p>
                        <ul class="list-unstyled small mb-0 ps-2 border-start border-3" style="border-color: #05445E !important;">
                            <li class="mb-1"><span class="text-muted">Bank:</span> <strong class="text-dark">BDO</strong></li>
                            <li class="mb-1"><span class="text-muted">Account No:</span> <strong class="text-dark">1234 5678 9012</strong></li>
                            <li><span class="text-muted">Account Name:</span> <strong class="text-dark">HouseMaster Inc.</strong></li>
                        </ul>
                    </div>

                    <div id="modalUploadSection" class="d-none">
                        <hr class="my-4 text-muted">
                        <p class="text-muted text-center mb-3 small">Upload a screenshot of your successful payment.</p>
                        <input type="hidden" name="payment_method" id="modalPaymentMethodInput">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary small text-uppercase">Payment Screenshot</label>
                            <input type="file" name="payment_proof" class="form-control shadow-none" accept="image/*" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 fw-bold py-2" style="background-color: #05445E; border: none;">Submit & Proceed</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleModalPaymentDetails() {
    const method = document.getElementById('modalPaymentMethod').value;
    const gcash = document.getElementById('modalGcashDetails');
    const bank = document.getElementById('modalBankDetails');
    const upload = document.getElementById('modalUploadSection');
    const paymentMethodInput = document.getElementById('modalPaymentMethodInput');

    gcash.classList.add('d-none');
    bank.classList.add('d-none');
    upload.classList.add('d-none');

    if (method === 'gcash') {
        gcash.classList.remove('d-none');
        upload.classList.remove('d-none');
        paymentMethodInput.value = 'gcash';
    } else if (method === 'bank') {
        bank.classList.remove('d-none');
        upload.classList.remove('d-none');
        paymentMethodInput.value = 'bank';
    }
}
</script>
