/**
 * HouseMaster Short Polling for auto-refreshing tabs.
 *
 * This script periodically checks with the server to see if any data has changed.
 * If a change is detected, it reloads the page. This works across all browser
 * windows, including normal and incognito modes.
 */
(function() {
    // Don't run on the login page
    if (window.location.pathname.includes('admin-login.php')) {
        return;
    }

    // The timestamp is injected into the page by PHP
    let lastKnownUpdate = window.housemaster_last_update || 0;
    const pollInterval = 5000; // Check every 5 seconds

    const checkForUpdates = () => {
        fetch(`check_updates.php?timestamp=${lastKnownUpdate}`)
            .then(response => {
                if (!response.ok) {
                    // If session expires or there's an error, stop polling
                    clearInterval(pollingId);
                    return null;
                }
                return response.json();
            })
            .then(data => {
                if (data && data.refresh) {
                    console.log('HouseMaster: Update detected from server. Reloading page.');
                    window.location.reload(true);
                }
            })
            .catch(error => console.error('HouseMaster: Auto-update poll failed.', error));
    };

    const pollingId = setInterval(checkForUpdates, pollInterval);
})();