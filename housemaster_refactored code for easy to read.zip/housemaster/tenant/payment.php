<?php
session_start();
include __DIR__ . "/../config.php";

// Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}

$tenant_id = $_SESSION["tenant_id"];

// Handle month filter
$month_filter = isset($_GET['month']) ? $_GET['month'] : "";

// Build query to fetch payments
$sql = "
    SELECT amount, due_date, status, created_at
    FROM payments
    WHERE tenant_id = ?
";

$params = [$tenant_id];
$types = "i";

if (!empty($month_filter) && is_numeric($month_filter)) {
    $sql .= " AND MONTH(due_date) = ?";
    $params[] = $month_filter;
    $types .= "i";
}

$sql .= " ORDER BY due_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$payments = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — My Payments</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>

<?php include("navbar.php"); ?>

<!-- Main Content -->
<div class="main">
  <h3 class="fw-bold text-dark mt-3">💳 My Payment History</h3>

  <!-- Filter -->
    <form method="GET" class="mb-3 mt-4">
      <div class="row g-2 align-items-center">
        <div class="col-md-4">
          <select name="month" class="form-select">
            <option value="">-- Filter by Month --</option>
            <?php
            $months = [
                '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
                '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
                '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
            ];
            foreach ($months as $num => $name) {
                $selected = ($month_filter == $num) ? 'selected' : '';
                echo "<option value='{$num}' {$selected}>{$name}</option>";
            }
            ?>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Apply</button>
        </div>
        <div class="col-md-2">
          <a href="payment.php" class="btn btn-secondary w-100">Reset</a>
        </div>
      </div>
    </form>

  <div class="card shadow-sm border-0 mt-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>Amount</th>
              <th>Due Date</th>
              <th>Status</th>
              <th>Billed On</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($payments->num_rows > 0): ?>
              <?php while ($row = $payments->fetch_assoc()): ?>
                <tr>
                  <td>₱<?php echo number_format($row['amount'], 2); ?></td>
                  <td><?php echo date("M d, Y", strtotime($row['due_date'])); ?></td>
                  <td>
                    <?php
                        $payment_status = $row['status'];
                        $display_status = ucfirst($payment_status);
                        $badge_class = 'warning';

                        if ($payment_status == 'paid') {
                            $badge_class = 'success';
                        } elseif ($payment_status == 'pending' && strtotime($row['due_date']) < time()) {
                            $display_status = 'Overdue';
                            $badge_class = 'danger';
                        }
                    ?>
                    <span class="badge bg-<?php echo $badge_class; ?>">
                      <?php echo $display_status; ?>
                    </span>
                  </td>
                  <td><?php echo date("M d, Y", strtotime($row['created_at'])); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="4" class="text-center text-muted">No payment records found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<footer class="text-center mt-5 mb-3 text-muted">
  HouseMaster © 2025 — Boarding House & Dormitory Management System
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>