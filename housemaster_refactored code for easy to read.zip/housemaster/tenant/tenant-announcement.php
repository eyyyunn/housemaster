<?php
session_start();
include __DIR__ . "/../config.php";

// Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}
$tenant_id = $_SESSION["tenant_id"];
$boarding_code_stmt = $conn->prepare("SELECT * FROM tenants WHERE id = ?");
$boarding_code_stmt->bind_param("i", $tenant_id);
$boarding_code_stmt->execute();
$tenant_data = $boarding_code_stmt->get_result()->fetch_assoc();
$boarding_code = $tenant_data ? $tenant_data['boarding_code'] : null;

// ✅ Fetch all notices
$result = null; // Initialize result to null
if (!empty($boarding_code)) { // Only fetch notices if boarding_code is valid
    $sql_notices = "SELECT * FROM notices WHERE boarding_code = ? ORDER BY created_at DESC";
    $stmt_notices = $conn->prepare($sql_notices);
    $stmt_notices->bind_param("s", $boarding_code);
    $stmt_notices->execute();
    $result = $stmt_notices->get_result();
} else {
    error_log("Tenant ID: " . $tenant_id . " has an empty or NULL boarding_code. No announcements fetched.");
}

// ✅ Separate the latest notice and the past ones
$latestNotice = null;
$pastNotices = [];
if ($result && $result->num_rows > 0) { // Check if $result is not null and has rows (after potential debugging output)
    $latestNotice = $result->fetch_assoc(); // first row is latest
    while ($row = $result->fetch_assoc()) {
        $pastNotices[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Announcements — HouseMaster</title>
    <link rel="stylesheet" href="tenant.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: "Inter", "Segoe UI", sans-serif;
            background: #f9fafb;
            margin: 0;
            padding: 0;
            color: #111827;
        }
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 0 20px;
        }
        h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: 700;
            color: #05445E;
            margin-bottom: 30px;
        }
        .latest-board {
            background: linear-gradient(135deg, #1a73e8, #2563eb);
            color: #fff;
            border-radius: 16px;
            padding: 40px 30px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            margin-bottom: 50px;
        }
        .latest-board h2 {
            font-size: 1.8rem;
            margin: 0 0 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .badge-new {
            background: #ff4757;
            color: #fff;
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .past-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .past-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        .past-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
        }
        .past-card h3 {
            font-size: 1.1rem;
            margin: 0 0 10px;
            color: #1a73e8;
            font-weight: 600;
        }
        .past-card p {
            font-size: 0.95rem;
            color: #444;
            line-height: 1.4;
            margin-bottom: 12px;
            max-height: 90px;
            overflow: hidden;
        }
        .past-card small {
            font-size: 0.8rem;
            color: #777;
        }
    </style>
</head>
<body>
<?php include("navbar.php"); ?>

<div class="container">
    <h3 class="fw-bold text-dark mt-3">📢 Announcements</h3>

    <?php if ($latestNotice): ?>
        <!-- Latest announcement board -->
        <div class="latest-board">
            <h2>
                <?= htmlspecialchars($latestNotice['title']) ?>
                <span class="badge-new">New</span>
            </h2>
            <p><?= nl2br(htmlspecialchars($latestNotice['body'])) ?></p>
            <small>Posted on <?= date("F j, Y, g:i a", strtotime($latestNotice['created_at'])) ?></small>
        </div>

        <!-- Past announcements -->
        <?php if (!empty($pastNotices)): ?>
            <h3 class="mb-3">Past Announcements</h3>
            <div class="past-grid">
                <?php foreach ($pastNotices as $row): ?>
                    <div class="past-card">
                        <h3><?= htmlspecialchars($row['title']) ?></h3>
                        <p><?= nl2br(htmlspecialchars($row['body'])) ?></p>
                        <small>Posted on <?= date("F j, Y, g:i a", strtotime($row['created_at'])) ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p class="text-center text-muted">No announcements yet.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
