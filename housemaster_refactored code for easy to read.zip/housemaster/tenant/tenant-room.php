<?php
session_start();
include __DIR__ . "/../config.php";

// ✅ Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}

$tenant_id = $_SESSION["tenant_id"];

// ✅ Fetch tenant info to get admin_id
$tenant_stmt = $conn->prepare("SELECT admin_id, boarding_code FROM tenants WHERE id = ?");
$tenant_stmt->bind_param("i", $tenant_id);
$tenant_stmt->execute();
$tenant = $tenant_stmt->get_result()->fetch_assoc();
$admin_id = $tenant['admin_id'] ?? null;

// ✅ Fetch tenant’s room assignment
$sql = "
    SELECT r.id AS room_id, r.room_label, r.capacity, r.rental_rate, t.start_boarding_date
    FROM tenant_rooms tr
    INNER JOIN rooms r ON tr.room_id = r.id
    INNER JOIN tenants t ON tr.tenant_id = t.id
    WHERE tr.tenant_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tenant_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

// ✅ Calculate duration of stay
$duration = null;
if ($room && $room['start_boarding_date']) {
    $assigned_date = new DateTime($room['start_boarding_date']);
    $now = new DateTime();
    $interval = $assigned_date->diff($now);
    $duration = $interval->y > 0 
        ? $interval->y . " year(s)" 
        : ($interval->m > 0 ? $interval->m . " month(s)" : $interval->d . " day(s)");
}

// ✅ Fetch next pending payment to calculate days remaining
$payment = null;
$days_remaining = null;
if ($room) {
    $payment_stmt = $conn->prepare("SELECT due_date FROM payments WHERE tenant_id = ? AND status = 'pending' ORDER BY due_date ASC LIMIT 1");
    $payment_stmt->bind_param("i", $tenant_id);
    $payment_stmt->execute();
    $payment = $payment_stmt->get_result()->fetch_assoc();

    if ($payment && $payment['due_date']) {
        $today = new DateTime();
        $today->setTime(0, 0, 0);
        $dueDate = new DateTime($payment['due_date']);
        $dueDate->setTime(0, 0, 0);
        $interval = $today->diff($dueDate);
        $days_remaining = (int)$interval->format('%r%a');
    }
}
// ✅ Fetch room items and rules if room exists
$items = [];
$rules = [];
if ($room) {
    // Fetch items
    $item_query = $conn->prepare("SELECT item_name, quantity, `condition` FROM room_items WHERE room_id = ? ORDER BY created_at ASC");
    $item_query->bind_param("i", $room['room_id']);
    $item_query->execute();
    $items = $item_query->get_result();

    // Fetch rules
    $rule_query = $conn->prepare("SELECT rule_text FROM room_rules WHERE room_id = ? AND type = 'rule' ORDER BY created_at ASC");
    $rule_query->bind_param("i", $room['room_id']);
    $rule_query->execute();
    $rules = $rule_query->get_result();

    // ✅ Fetch all messages for the chat modal
    $messages_stmt = $conn->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
    $messages_stmt->bind_param("iiii", $tenant_id, $admin_id, $admin_id, $tenant_id);
    $messages_stmt->execute();
    $recent_messages = $messages_stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Room — HouseMaster</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/adminlte.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>
  <!-- Navbar -->
  <?php include("navbar.php"); ?>

  <!-- Main Content -->
  <div class="container my-4">
    <h3 class="fw-bold text-dark mb-4 text-center">My Room</h3>

    <div class="row g-4">
      <!-- Room Information -->
      <div class="col-lg-8">
        <div class="card shadow-sm border-0">
          <div class="card-header bg-primary text-white fw-bold">Room Information</div>
          <div class="card-body p-0">
            <table class="table table-bordered mb-0">
              <tbody>
                <?php if ($room): ?>
                  <tr>
                    <th scope="row">Boarding House Code</th>
                    <td><span class="badge bg-primary"><?php echo htmlspecialchars($tenant['boarding_code']); ?></span></td>
                  </tr>
                  <tr>
                    <th scope="row">Room Label</th>
                    <td><?php echo htmlspecialchars($room['room_label']); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Capacity</th>
                    <td><?php echo htmlspecialchars($room['capacity']); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Monthly Rent</th>
                    <td>₱<?php echo number_format($room['rental_rate'], 2); ?> / Month</td>
                  </tr>
                  <tr>
                    <th scope="row">Move-in Date</th>
                    <td><?php echo date("M d, Y", strtotime($room['start_boarding_date'])); ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Duration of Stay</th>
                    <td><?php echo $duration ?: "N/A"; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Days Until Next Bill</th>
                    <td>
                      <?php
                        if ($days_remaining !== null) {
                            if ($days_remaining < 0) {
                                echo '<span class="badge bg-danger">Overdue by ' . abs($days_remaining) . ' days</span>';
                            } elseif ($days_remaining <= 7) {
                                echo '<span class="badge bg-warning">' . $days_remaining . ' days</span>';
                            } else {
                                echo '<span class="badge bg-info">' . $days_remaining . ' days</span>';
                            }
                        } else {
                            echo '<span class="text-muted">No pending payment</span>';
                        }
                      ?>
                    </td>
                  </tr>
                <?php else: ?>
                  <tr>
                    <td colspan="2" class="text-center text-muted">No room assigned yet.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

        <!-- Right Column -->
      <div class="col-lg-4">
      <!-- Room Inclusions -->
      <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-primary text-white fw-bold"><i class="fas fa-check-circle me-2"></i>Room Inclusions</div>
        <div class="card-body">
          <ul class="list-group list-group-flush">
            <?php if ($room && $items->num_rows > 0): ?>
              <?php while ($item = $items->fetch_assoc()): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  <?php echo htmlspecialchars($item['item_name']); ?>
                  <div>
                    <span class="badge bg-secondary">x<?php echo htmlspecialchars($item['quantity']); ?></span>
                    <span class="badge bg-info text-dark"><?php echo htmlspecialchars($item['condition']); ?></span>
                  </div>
                </li>
              <?php endwhile; ?>
            <?php else: ?>
              <li class="list-group-item text-muted">No specific items listed.</li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <!-- House Rules -->
      <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-warning text-dark fw-bold"><i class="fas fa-gavel me-2"></i>House Rules & Reminders</div>
        <div class="card-body">
          <ul class="list-group list-group-flush">
            <?php if ($room && $rules->num_rows > 0): ?>
              <?php while ($rule = $rules->fetch_assoc()): ?>
                <li class="list-group-item"><?php echo htmlspecialchars(trim($rule['rule_text'])); ?></li>
              <?php endwhile; ?>
            <?php elseif ($room): ?>
              <li class="list-group-item text-muted">No rules set for this room.</li>
            <?php else: ?>
              <li class="text-muted">No room assigned.</li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <!-- Maintenance -->
      <div class="card shadow-sm border-0 mt-4">
        <div class="card-header bg-secondary text-white fw-bold"><i class="fas fa-tools me-2"></i>Maintenance & Requests</div>
        <div class="card-body">
          <p class="mb-2">Have an issue? You can chat with your landlord directly.</p>
          <button class="btn btn-info w-100" data-bs-toggle="modal" data-bs-target="#supportModal">
            Chat with Admin
          </button>
        </div>
      </div>
      </div>

    </div>
  </div>

  <!-- Support Chat Modal -->
  <div class="modal fade" id="supportModal" tabindex="-1" aria-labelledby="supportModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="supportModalLabel">💬 Support — Chat with Admin</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="chat-box mb-3">
            <?php if ($room && $recent_messages->num_rows > 0): ?>
              <?php while($msg = $recent_messages->fetch_assoc()): ?>
                <div class="chat-message <?php echo htmlspecialchars($msg['sender_type']); ?>" data-message-id="<?php echo $msg['id']; ?>">
                  <div class="chat-bubble <?php echo htmlspecialchars($msg['sender_type']); ?>">
                      <?php echo htmlspecialchars($msg['message']); ?>
                      <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;"><?php echo date("h:i A", strtotime($msg['created_at'])); ?></div>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <p class="text-center text-muted">No messages yet. Start the conversation!</p>
            <?php endif; ?>
          </div>
        </div>
        <div class="modal-footer">
          <form id="support-chat-form-room" class="d-flex w-100">
            <input type="text" id="chat-message-input-room" class="form-control me-2" placeholder="Type your message..." required autocomplete="off">
            <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <footer class="text-center mt-5 mb-3 text-muted">
    HouseMaster © 2025 — Boarding House & Dormitory Management System
  </footer>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Custom polling for auto-refresh -->
  <script>
    // Pass the server's last update timestamp to the JavaScript poller.
    <?php
        $ts_stmt = $conn->query("SELECT state_value FROM system_state WHERE state_key = 'last_update_timestamp'");
        $current_ts = $ts_stmt->fetch_assoc()['state_value'];
    ?>
    window.housemaster_last_update = <?php echo $current_ts ?: 0; ?>;
  </script>
  <script src="../admin/assets/js/autoupdate.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        const supportModal = document.getElementById('supportModal');
        const chatForm = document.getElementById('support-chat-form-room');
        const chatBox = supportModal.querySelector('.chat-box');

        // Function to scroll to the bottom of the chat
        function scrollToBottom() {
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        // When the modal is shown, scroll to the bottom
        supportModal.addEventListener('shown.bs.modal', function () {
            startChatPolling();
            scrollToBottom();
        });

        // When the modal is hidden, stop polling
        supportModal.addEventListener('hidden.bs.modal', function () {
            stopChatPolling();
        });

        // Handle form submission with AJAX
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const messageInput = document.getElementById('chat-message-input-room');
            const message = messageInput.value.trim();

            if (message === '') {
                return;
            }

            const formData = new FormData();
            formData.append('message', message);

            fetch('send_tenant_message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert('Error: ' + data.error);
                } else {
                    // Clear input
                    messageInput.value = '';

                    // Append new message to chat box
                    const messageHtml = `
                        <div class="chat-message tenant" data-message-id="${data.id}">
                            <div class="chat-bubble tenant">
                                ${escapeHtml(data.message)}
                                <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${data.created_at}</div>
                            </div>
                        </div>`;
                    chatBox.insertAdjacentHTML('beforeend', messageHtml);
                    scrollToBottom();
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    function escapeHtml(unsafe) {
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // --- Chat Polling Logic ---
    let chatPollInterval;

    function startChatPolling() {
        stopChatPolling();
        fetchNewMessages();
        chatPollInterval = setInterval(fetchNewMessages, 3000); // Poll every 3 seconds
    }

    function stopChatPolling() {
        clearInterval(chatPollInterval);
    }

    function fetchNewMessages() {
        const chatBox = document.querySelector('#supportModal .chat-box');
        const lastMessage = chatBox.querySelector('.chat-message:last-child');
        const lastId = lastMessage ? lastMessage.getAttribute('data-message-id') : 0;
        
        const url = `../get_new_messages.php?last_id=${lastId}`;

        fetch(url)
            .then(response => response.json())
            .then(messages => {
                if (messages.length > 0) {
                    messages.forEach(msg => {
                        if (msg.sender_type === 'admin') {
                            const messageHtml = `
                                <div class="chat-message ${msg.sender_type}" data-message-id="${msg.id}">
                                    <div class="chat-bubble ${msg.sender_type}">
                                        ${msg.message}
                                        <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${msg.created_at_formatted}</div>
                                    </div>
                                </div>`;
                            chatBox.insertAdjacentHTML('beforeend', messageHtml);
                        }
                    });
                    chatBox.scrollTop = chatBox.scrollHeight;
                    window.housemaster_last_update = messages[messages.length - 1].created_at_timestamp;
                }
            })
            .catch(error => console.error('Chat poll error:', error));
    }
  </script>
</body>
</html>
