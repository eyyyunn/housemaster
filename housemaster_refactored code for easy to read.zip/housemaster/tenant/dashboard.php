<?php
session_start();
include __DIR__ . "/../config.php";  // config is outside /tenant folder

//  Require tenant login
if (!isset($_SESSION["tenant_id"])) {
    header("Location: tenant-auth.php");
    exit();
}

$tenant_id = $_SESSION["tenant_id"];

//  Fetch tenant info
$tenant_stmt = $conn->prepare("SELECT * FROM tenants WHERE id = ?");
$tenant_stmt->bind_param("i", $tenant_id);
$tenant_stmt->execute();
$tenant = $tenant_stmt->get_result()->fetch_assoc();

//  If tenant is inactive, log them out
if ($tenant['status'] === 'inactive') {
    header("Location: ../tenant-logout.php?reason=inactive");
    exit();
}

//  Fetch room assignment (if exists)
$room = $conn->query("
    SELECT r.* FROM rooms r
    INNER JOIN tenant_rooms tr ON r.id = tr.room_id
    WHERE tr.tenant_id = $tenant_id
")->fetch_assoc();

//  Next PENDING payment
$payment_stmt = $conn->prepare("
    SELECT * FROM payments
    WHERE tenant_id = ? AND status = 'pending'
    ORDER BY due_date ASC LIMIT 1");
$payment_stmt->bind_param("i", $tenant_id);
$payment_stmt->execute();
$payment = $payment_stmt->get_result()->fetch_assoc();

//  Recent notices (last 3)
$latest_notice = null;
$boarding_code = $tenant['boarding_code'];
$notices_stmt = $conn->prepare("SELECT * FROM notices WHERE boarding_code = ? ORDER BY created_at DESC LIMIT 1");
$notices_stmt->bind_param("s", $boarding_code);
$notices_stmt->execute();
$latest_notice = $notices_stmt->get_result()->fetch_assoc();

//  Fetch all messages for the chat modal
$admin_id = $tenant['admin_id'];
$messages_stmt = $conn->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
$messages_stmt->bind_param("iiii", $tenant_id, $admin_id, $admin_id, $tenant_id);
$messages_stmt->execute();
$recent_messages = $messages_stmt->get_result();


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HouseMaster — Tenant Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/adminlte.min.css">
  <link rel="stylesheet" href="tenant.css">
</head>
<body>

<?php include("navbar.php"); ?>

<!-- Dashboard Content --> 
<div class="main">
  <div class="d-flex justify-content-between align-items-center">
      <h3 class="fw-bold text-dark mt-3 mb-0">👋 Welcome, <?php echo htmlspecialchars($tenant["fullname"]); ?>!</h3>
      <?php if (!empty($tenant['boarding_code'])): ?>
          <div class="text-end">
              <h5 class="mb-0">Boarding House Code: 
                  <span class="badge bg-primary fs-5"><?php echo htmlspecialchars($tenant['boarding_code']); ?></span>
              </h5>
          </div>
      <?php endif; ?>
  </div>

  <div class="row mt-4">
    <!-- Room Status -->
    <div class="col-md-4 d-flex">
      <div class="card shadow-sm border-0 text-center w-100 d-flex flex-column justify-content-center">
        <div class="card-body">
          <h5 class="card-title">My Room</h5>
          <?php if ($room): ?>
            <p class="fs-4 fw-bold text-primary"><?php echo htmlspecialchars($room["room_label"]); ?></p>
            <p class="text-muted">Capacity: <?php echo $room["capacity"]; ?> | Rent: ₱<?php echo number_format($room["rental_rate"]); ?></p>
          <?php else: ?>
            <p class="text-muted">No room assigned yet.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Next Due Payment -->
    <div class="col-md-4 d-flex">
      <div class="card shadow-sm border-0 text-center w-100 d-flex flex-column justify-content-center">
        <div class="card-body">
          <h5 class="card-title">Next Due Payment</h5>
          <?php if ($payment): ?>
            <p class="fs-4 fw-bold text-warning">₱<?php echo number_format($payment["amount"]); ?></p>
            <p class="text-muted">Due: <?php echo date("M d, Y", strtotime($payment["due_date"])); ?></p>
            <p>Status:
              <?php
                  $payment_status = $payment['status'];
                  $display_status = ucfirst($payment_status);
                  $badge_class = 'warning';

                  if ($payment_status == 'pending' && strtotime($payment['due_date']) < time()) {
                      $display_status = 'Overdue';
                      $badge_class = 'danger';
                  }
              ?>
              <span class="badge bg-<?php echo $badge_class; ?>">
                <?php echo $display_status; ?>
              </span>
            </p>
          <?php else: ?>
            <p class="text-muted">No upcoming payments.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <!-- Support -->
    <div class="col-md-4 d-flex">
        <div class="card shadow-sm border-0 w-100 d-flex flex-column justify-content-center">
            <div class="card-body text-center">
                <h5 class="card-title">Support</h5>
                <p class="fs-4 fw-bold text-info"><i class="fas fa-envelope"></i></p>
                <p class="text-muted" id="unread-message-text">You have <?php echo $unread_messages; ?> unread message(s).</p>
                <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#supportModal">
                    Open Chat
                </button>
            </div>
        </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Latest Announcements -->
    <div class="col-md-12">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title mb-0">Latest Announcement</h5>
            <a href="tenant-announcement.php" class="btn btn-sm btn-outline-secondary">View All</a>
          </div>
          <?php if ($latest_notice): ?>
            <div>
              <h6><strong><?php echo htmlspecialchars($latest_notice["title"]); ?></strong></h6>
              <p class="text-muted mb-2" style="font-size: 0.9rem;"><?php echo htmlspecialchars(substr($latest_notice['body'], 0, 150)) . (strlen($latest_notice['body']) > 150 ? '...' : ''); ?></p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Posted on: <?php echo date("M d, Y", strtotime($latest_notice["created_at"])); ?></small>
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#noticeModalTenant<?php echo $latest_notice['id']; ?>"><i class="fas fa-eye"></i></button>
              </div>
            </div>
          <?php else: ?>
            <p class="text-muted">No new announcements.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Support Chat Modal -->
<div class="modal fade" id="supportModal" tabindex="-1" aria-labelledby="supportModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="supportModalLabel">💬 Support — Chat with Admin</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="chat-box mb-3">
          <?php if ($recent_messages->num_rows > 0): ?>
            <?php while($msg = $recent_messages->fetch_assoc()): ?>
              <div class="chat-message <?php echo htmlspecialchars($msg['sender_type']); ?>" data-message-id="<?php echo $msg['id']; ?>">
                <div class="chat-bubble <?php echo htmlspecialchars($msg['sender_type']); ?>">
                    <?php echo htmlspecialchars($msg['message']); ?>
                    <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;"><?php echo date("h:i A", strtotime($msg['created_at'])); ?></div>
                </div>
              </div>
            <?php endwhile; ?>
          <?php else: ?>
            <p class="text-center text-muted">No messages yet. Start the conversation!</p>
          <?php endif; ?>
        </div>
      </div>
      <div class="modal-footer">
        <form id="support-chat-form" class="d-flex w-100">
          <input type="text" id="chat-message-input" class="form-control me-2" placeholder="Type your message..." required autocomplete="off">
          <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Announcement Modals -->
<?php
  // We only need a modal for the single latest notice now
  if ($latest_notice):
?>
<div class="modal fade" id="noticeModalTenant<?php echo $latest_notice['id']; ?>" tabindex="-1" aria-labelledby="noticeModalLabelTenant<?php echo $latest_notice['id']; ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="noticeModalLabelTenant<?php echo $latest_notice['id']; ?>"><?php echo htmlspecialchars($latest_notice['title']); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p><small class="text-muted">Posted on: <?php echo date("F j, Y, g:i a", strtotime($latest_notice['created_at'])); ?></small></p>
        <hr>
        <p><?php echo nl2br(htmlspecialchars($latest_notice['body'])); ?></p>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<footer class="text-center mt-5 mb-3 text-muted">
  HouseMaster © 2025 — Boarding House & Dormitory Management System
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Pass the server's last update timestamp to the JavaScript poller.
    <?php
        $ts_stmt = $conn->query("SELECT state_value FROM system_state WHERE state_key = 'last_update_timestamp'");
        $current_ts = $ts_stmt->fetch_assoc()['state_value'];
    ?>
    window.housemaster_last_update = <?php echo $current_ts ?: 0; ?>;
</script>
<script src="../admin/assets/js/autoupdate.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const supportModal = document.getElementById('supportModal');
        const chatForm = document.getElementById('support-chat-form');
        const chatBox = supportModal.querySelector('.chat-box');

        // Function to scroll to the bottom of the chat
        function scrollToBottom() {
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        // When the modal is shown, scroll to the bottom
        supportModal.addEventListener('shown.bs.modal', function () {
            startChatPolling();
            scrollToBottom();
            
            // Mark messages as read via AJAX
            fetch('mark_messages_read.php', { method: 'POST' })
                .then(response => {
                    if (response.ok) {
                        // Optionally, update the UI to remove the unread badge without a page reload
                        const unreadBadge = document.querySelector('.position-absolute.top-0.start-100.translate-middle.badge');
                        const unreadText = document.getElementById('unread-message-text');
                        
                        if (unreadText) unreadText.textContent = 'You have 0 unread message(s).';
                        if (unreadBadge) unreadBadge.remove();
                    }
                });
        });

        // When the modal is hidden, stop polling
        supportModal.addEventListener('hidden.bs.modal', function () {
            stopChatPolling();
        });


        // Handle form submission with AJAX
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const messageInput = document.getElementById('chat-message-input');
            const message = messageInput.value.trim();

            if (message === '') {
                return;
            }

            const formData = new FormData();
            formData.append('message', message);

            fetch('send_tenant_message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert('Error: ' + data.error);
                } else {
                    // Clear input
                    messageInput.value = '';

                    // Append new message to chat box
                    const messageHtml = `
                        <div class="chat-message tenant" data-message-id="${data.id}">
                            <div class="chat-bubble tenant">
                                ${escapeHtml(data.message)}
                                <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${data.created_at}</div>
                            </div>
                        </div>`;
                    chatBox.insertAdjacentHTML('beforeend', messageHtml);
                    scrollToBottom();
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    function escapeHtml(unsafe) {
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // --- Chat Polling Logic ---
    let chatPollInterval;

    function startChatPolling() {
        // Clear any existing interval
        stopChatPolling(); 

        // Start polling immediately, then every 3 seconds
        fetchNewMessages();
        chatPollInterval = setInterval(fetchNewMessages, 3000);
    }

    function stopChatPolling() {
        clearInterval(chatPollInterval);
    }

    function fetchNewMessages() {
        const chatBox = document.querySelector('#supportModal .chat-box');
        const lastMessage = chatBox.querySelector('.chat-message:last-child');
        const lastId = lastMessage ? lastMessage.getAttribute('data-message-id') : 0;

        // Note: We use ../get_new_messages.php because this file is in the /tenant/ directory
        fetch(`../get_new_messages.php?last_id=${lastId}`)
            .then(response => response.json())
            .then(messages => {
                if (messages.length > 0) {
                    messages.forEach(msg => {
                        // Only append messages from the other user (admin)
                        if (msg.sender_type === 'admin') {
                            const messageHtml = `
                                <div class="chat-message ${msg.sender_type}" data-message-id="${msg.id}">
                                    <div class="chat-bubble ${msg.sender_type}">
                                        ${msg.message}
                                        <div class="text-end text-muted mt-1" style="font-size: 0.7rem; opacity: 0.7;">${msg.created_at_formatted}</div>
                                    </div>
                                </div>`;
                            chatBox.insertAdjacentHTML('beforeend', messageHtml);
                        }
                    });
                    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to new message
                }
                 // If we received new messages, update the global timestamp
                 // to prevent the main page poller from doing a full reload.
                 if (messages.length > 0) {
                    window.housemaster_last_update = messages[messages.length - 1].created_at_timestamp;
                 }
            });
    }
</script>
</body>
</html>
